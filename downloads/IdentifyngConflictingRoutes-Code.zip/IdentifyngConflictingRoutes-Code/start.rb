require './lib/interface'
require './lib/graph'
require './lib/vertex'
require './lib/signal'
require './lib/track'
require './lib/path'
require './lib/edge'
require './lib/label'
require './lib/routes_generator'
require './lib/control_table_generator'
require './lib/consistent_routes_combination_verifier'
require './lib/control_table'
require './lib/program_generator'
require './lib/reports'
require './lib/output'
require './lib/analyzer'

# Call the class method 'main' of Interface class
# This can also be run from ruby console (irb)
# Just copy paste the lines of this file. It will work.

puts "Reading the input file name from input.rly"
begin
  # Open the file to read
  file_in = File.new("input.rly", "r")
  # Read the first line from file
  file_name = file_in.gets.chomp
  # Close the file
  file_in.close
  puts "The input file name is: #{file_name}"
  # Create an object for Interface class and
  # call its instance method 'read_input' to read the input
  graph = Interface.new.read_input file_name
  Report.interface graph, file_name # Generate Interface's report

  # Call the 'path_generator' method to generate all paths
  # for the given Railway section layout
  paths = RouteGenerator.new.generate_all_paths file_name, graph
  Report.route_generator paths, file_name # Generate RouteGenerator's report

  # Call ControlTableGenerator class' instance method 'generate_control_table'
  # to generate control table entries
  control_table_entries = ControlTableGenerator.new.generate_control_table file_name, graph, paths
  Report.control_table_generator control_table_entries, file_name # Generate ControlTableGenerator's report

  # Call 'find_conflict_paths' method of ConsistentRoutesCombinationVerifier
  # class using its instance
  conflict_routes = ConsistentRoutesCombinationVerifier.new.find_conflict_paths file_name, graph, control_table_entries
  Report.consistent_routes_combination_verifier control_table_entries, conflict_routes, file_name # Generate ConsistentRoutesCombinationVerifier's report

  # Generate final output
  Output.print control_table_entries, conflict_routes, file_name

# Handle the exceptions that can occur during the execution
rescue => e
  puts "Exception occurred: #{e.message}"
  puts "Backtrace:"
  e.backtrace.each do |trace|
    puts "  #{trace}"
  end
end