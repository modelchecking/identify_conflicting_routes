=begin
 * Edge class
 *
 * Class to implement and perform Edge operations
=end
class Edge

  # Vertex instance on the UP direction of edge
  @up_vertex
  # Vertex instance on the DOWN direction of edge
  @down_vertex

  # Constructor method
  def initialize
    # Initializing the attributes according to their class
    @up_vertex = nil
    @down_vertex = nil
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Vertex instance on the UP direction
  #
  # Method to get the Vertex instance on UP direction
  def get_up_vertex
    @up_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. up_vertex - Vertex instance on the UP direction of edge
  # Returns: Vertex instance on the UP direction of edge
  #
  # Method to set the Vertex instance on the UP direction of edge
  def set_up_vertex= up_vertex
    @up_vertex = up_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Vertex instance on the DOWN direction
  #
  # Method to get the Vertex instance on DOWN direction
  def get_down_vertex
    @down_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. down_vertex - Vertex instance on the DOWN direction of edge
  # Returns: Vertex instance on the DOWN direction of edge
  #
  # Method to set the Vertex instance on the DOWN direction of edge
  def set_down_vertex= down_vertex
    @down_vertex = down_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: String denoting the attributes for instance of Edge
  #
  # Method to get the attributes value for instance of Edge
  def to_s
    "<Edge: #{@up_vertex} - #{@down_vertex}>"
  end
end