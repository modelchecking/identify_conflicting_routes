=begin
 * Report module
 *
 * Module to print report for every module
=end
module Report

  # Scope: Public
  # Type: Class method
  # Parameters:
  #   1. graph     - Graph instance which has whole of the input
  #   2. file_name - Name of the input file
  # Returns: NA
  #
  # Method to print report for Interface module(module 1) as CSV file
  def self.interface graph, file_name
    create_folder file_name
    dir_name = get_dir_name file_name
    puts "Generating report for interface module at #{dir_name}/interface_report.csv"
    interface_file = open("#{dir_name}/interface_report.csv", 'w')
    [:vertices, :terminals, :tracks, :signals, :labels].each do |attribute|
      graph_attribute = graph.get_attribute attribute
      interface_file.puts "#{attribute.capitalize} objects count,#{graph_attribute.length}"
    end
    puts "Generating report for interface module done"
    interface_file.close
  end

  # Scope: Public
  # Type: Class method
  # Parameters:
  #   1. paths     - Paths computed by the RoutesGenerator module
  #   2. file_name - Name of the input file
  # Returns: NA
  #
  # Method to print report for RoutesGenerator module(module 2) as CSV file
  def self.route_generator paths, file_name
    create_folder file_name
    dir_name = get_dir_name file_name
    puts "Generating report for route generator module at #{dir_name}/route_gen_report.csv"
    route_gen_file = open("#{dir_name}/route_gen_report.csv", 'w')
    route_gen_file.puts "Signal,Signal Type,Label,To Direction,Path"
    paths.each do |path|
      signal = path.get_source_signal
      signal_type = TrainSignal::Type::MAPPING.invert[signal.get_type]
      signal_type = signal_type.gsub('_', ' ').capitalize
      label = path.get_destination_label
      signal_dir = TrainSignal::Direction::MAPPING.invert[signal.get_direction].capitalize
      route_path = if(signal.get_type == TrainSignal::Type::CALLING_ON_HOME)
          ['-', '-']
        else
          ControlTableGenerator.compute_path_as_array path.get_path
        end
      route_gen_file.puts "#{signal.get_data},#{signal_type},#{label},#{signal_dir},#{route_path.join('-')}"
    end
    puts "Generating report for route generator module done"
    route_gen_file.close
  end

  # Scope: Public
  # Type: Class method
  # Parameters:
  #   1. control_table_entries - Array of ControlTable instances
  #   2. file_name             - Name of the input file
  # Returns: NA
  #
  # Method to print report for ControlTableGenerator module(module 3) as CSV
  # file
  def self.control_table_generator control_table_entries, file_name
    create_folder file_name
    dir_name = get_dir_name file_name
    puts "Generating report for control table generator module at #{dir_name}/control_table_gen_report.csv"
    ctrl_tbl_gen_file = open("#{dir_name}/control_table_gen_report.csv", 'w')
    ctrl_tbl_gen_file.puts "Signal,Signal Type,Label,To Direction,Controlled by tracks,Locks and detects points"
    control_table_entries.each do |control_table_entry|
      signal = control_table_entry.get_source_signal
      if control_table_entry.get_point_info
        signal_type = "---"
        signal_dir = "---"
      else
        signal_type = TrainSignal::Type::MAPPING.invert[signal.get_type]
        signal_type = signal_type.gsub('_', ' ').capitalize
        signal_dir = TrainSignal::Direction::MAPPING.invert[signal.get_direction].capitalize
        signal = signal.get_data
      end
      label = control_table_entry.get_destination_label
      route_path = control_table_entry.get_controlled_by_tracks_array
      route_path = (route_path && route_path.length > 0) ? route_path : ['-', '-']
      lnd_points = control_table_entry.get_locks_and_detects_points
      lnd_points = Vertex.display_points(lnd_points)
      lnd_points = (lnd_points.length > 0) ? lnd_points.join(' ') : "---"
      report = "#{signal},#{signal_type},#{label},#{signal_dir},#{route_path.join('-')},#{lnd_points}"
      ctrl_tbl_gen_file.puts report
    end
    puts "Generating report for control table generator module done"
    ctrl_tbl_gen_file.close
  end

  # Scope: Public
  # Type: Class method
  # Parameters:
  #   1. control_table_entries - Array of ControlTable instances
  #   2. conflict_routes       - Hash value having inconsistent routes
  #   3. file_name             - Name of the input file
  # Returns: NA
  #
  # Method to print report for ConsistentRoutesCombinationVerifier
  # module(module 4) as CSV file
  def self.consistent_routes_combination_verifier control_table_entries, conflict_routes, file_name
    create_folder file_name
    dir_name = get_dir_name file_name
    puts "Generating report for consistent routes combination verifier module at #{dir_name}/control_table_verify_report.csv"
    ctrl_tbl_ver_file = open("#{dir_name}/consistent_routes_combo_verify_report.csv", 'w')
    control_table_entries.each do |control_table_entry|
      conflicting_routes = conflict_routes[control_table_entry.to_s]
      ctrl_tbl_ver_file.puts "#{control_table_entry},#{conflicting_routes.join(' ')}"
    end
    puts "Generating report for consistent routes combination verifier module done"
    ctrl_tbl_ver_file.close
  end

  private

    # Scope: Private
    # Type: Class method
    # Parameters:
    #   1. file_name - Name of the input file
    # Returns: NA
    #
    # Method to create folder to store report files
    def self.create_folder file_name
      dir_name = get_dir_name file_name
      # Create folder if it does not exists
      Dir.mkdir("output") unless File.exists? "output"
      Dir.mkdir(dir_name) unless File.exists? dir_name
    end

    # Scope: Private
    # Type: Class method
    # Parameters:
    #   1. file_name - Name of the input file
    # Returns: String denoting the folder structure to store report files
    #
    # Method to get the folder structure for storing report files as string
    def self.get_dir_name file_name
      "output/#{file_name.gsub('.', '_')}"
    end
end