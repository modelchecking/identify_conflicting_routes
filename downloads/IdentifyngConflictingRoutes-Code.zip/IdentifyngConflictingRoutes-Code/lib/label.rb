=begin
 * Label class
 *
 * Class to implement and perform Label operations
=end
class Label

  # ID of label
  @data
  # Boolean value denoting whether the label is for platform or not
  # TRUE means platform and vice-versa
  @platform

  # Constructor method
  def initialize
    # Initializing the attributes according to their class
    @data = nil
    @platform = false
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: ID of label
  #
  # Method to get the ID of label
  def get_data
    @data
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. data - ID of label
  # Returns: ID of label
  #
  # Method to set the ID of label
  def set_data= data
    @data = data
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Boolean value denoting whether the label is platform or not
  #
  # Method to get the platform status of a label
  def get_platform
    @platform
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. platform - Boolean value denoting whether the label is platform or not
  # Returns: Boolean value denoting whether the label is platform or not
  #
  # Method to set the platform status of a label
  def set_platform= platform
    @platform = platform
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: String denoting the attributes for instance of Label
  #
  # Method to get the attributes value for instance of label
  def to_s
    "Label: #{@data} - #{@platform}"
  end
end