=begin
 * Track class
 *
 * Class to implement and perform Track operations
=end
class Track

  # ID of the track stored as data
  @data
  # Array of vertices that come under the track ID
  @vertices

  # Constructor method
  def initialize
    # Initializing the attributes according to their class
    @data = nil
    @vertices = []
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: String denoting ID of Track
  #
  # Method to read the data attribute
  def get_data
    return @data
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: String denoting ID of Track
  # Returns: String denoting ID of Track
  #
  # Method to write the data attribute
  def set_data= data
    @data = data
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Array of vertex instances that come under the track
  #
  # Method to read the vertices attribute
  def get_vertices
    @vertices
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. vertex - Instance of vertex
  # Returns: Array of vertices that come under the current Track instance
  #
  # Method to add an instance of Vertex
  def add_vertex vertex
    @vertices << vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: String denoting the attributes for instance of Track
  #
  # Method to get the attributes value of instance of Track
  def to_s
    "<Track: #{@data}, #{@vertices}>"
  end
end