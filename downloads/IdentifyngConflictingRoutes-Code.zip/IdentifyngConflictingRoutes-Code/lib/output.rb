=begin
 * Output module
 *
 * Module to print the final output as PDF file compiled using LaTeX software
=end
module Output

  # Scope: Public
  # Type: Class method
  # Parameters:
  #   1. control_table_entries - Array of ControlTable instances
  #   2. conflict_routes       - Conflict routes as hash instance
  #   3. file_name             - Name of the input file
  # Returns: NA
  #
  # Method to produce final output (Control Table) as PDF file using LaTeX
  def self.print control_table_entries, conflict_routes, file_name
    file_name_path = "output/#{file_name.gsub('.', '_')}/latex_files"
    # Create the folder if it does not exists
    Dir.mkdir(file_name_path) unless File.exists? file_name_path
    tex_file_name = "#{file_name.split('.')[0]}_texfile.tex"
    puts "Generating the output as '#{tex_file_name.split('.')[0]}.pdf'"
    # Generate the LaTeX code
    file_content  = "#{92.chr}documentclass{memoir}\n\n"
    file_content += "#{92.chr}usepackage[landscape]{geometry}\n"
    file_content += "#{92.chr}usepackage{multirow}\n\n"
    file_content += "#{92.chr}usepackage{longtable}\n\n"
    file_content += "#{92.chr}begin{document}\n"
    file_content += "  #{92.chr}title{#{92.chr}textbf{Control Table generated from "
    file_content += "#{file_name.split('.')[0].gsub('_', ' ').capitalize} "
    file_content += "input}}\n"
    file_content += "#{92.chr}date{#{Time.now.strftime("%B %d, %Y")}}\n"
    file_content += "  #{92.chr}author{Dr. S. Sheerazuddin, Mr. K. Sriram}\n"
    file_content += "  #{92.chr}maketitle\n"
    file_content += "  #{92.chr}hrule\n"
    file_content += "  #{92.chr}begin{longtable}{|m{2cm}|m{1.2cm}|m{1.2cm}|m{3cm}|"
    file_content += "m{4.5cm}|m{5cm}|}\n"
    file_content += "    #{92.chr}hline\n"
    file_content += "    #{92.chr}textbf{Description} & #{92.chr}textbf{Signal} & "
    file_content += "#{92.chr}textbf{Label} & #{92.chr}textbf{Locks and Detects Points} & "
    file_content += "#{92.chr}textbf{Locks Routes} & #{92.chr}textbf{Controlled by Tracks} "
    file_content += "#{92.chr}#{92.chr}\n"
    file_content += "    #{92.chr}hline\n"
    file_content += "    #{92.chr}endhead\n"
    control_table_entries.each do |control_table_entry|
      signal = control_table_entry.get_source_signal
      label = control_table_entry.get_destination_label
      if signal.is_a?(String)
        row = "    Cross over points & "
        signal_data = signal
      else
        row  = TrainSignal::Direction::MAPPING.invert[signal.get_direction]
        row  = row.capitalize
        signal_type = TrainSignal::Type::MAPPING.invert[signal.get_type]
        signal_type = signal_type.gsub('_', ' ').capitalize
        row  = "    #{row} from #{signal_type} signal & "
        signal_data = signal.get_data
      end
      row += "#{signal_data} & #{label} & "
      lnd_points = control_table_entry.get_locks_and_detects_points
      lnd_points = Vertex.display_points(lnd_points)
      lnd_points = (lnd_points.length > 0) ? lnd_points.join(', ') : "---"
      row += "#{lnd_points} & "
      conflicting_routes = conflict_routes[control_table_entry.to_s]
      row += "#{conflicting_routes.join(', ')} & "
      route_path = control_table_entry.get_controlled_by_tracks_array
      route_path = if (route_path && route_path.length > 0)
          route_path.join(', ')
        else
          '---'
        end
      row += "#{route_path}#{92.chr}#{92.chr}\n      #{92.chr}hline\n"
      file_content += row
    end
    file_content += "  #{92.chr}end{longtable}\n"
    file_content += "#{92.chr}end{document}"
    File.open("#{file_name_path}/#{tex_file_name}", 'w') do |file|
      file.puts file_content
    end
    # Compile the LaTeX code
    `pdflatex #{file_name_path}/#{tex_file_name}`
    # Remove temporary files
    `rm *.aux`
    `rm *.log`
    # Move the final output PDF file to its folder
    `mv #{tex_file_name.split('.')[0]}.pdf output/#{file_name.gsub('.', '_')}/`
    puts "Generating the output done!"
  end
end