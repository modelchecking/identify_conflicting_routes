=begin
 * ConsistentRoutesCombinationVerifier class
 *
 * Class to identify which combinations of routes are inconsistent
=end
class ConsistentRoutesCombinationVerifier

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. file_name             - Name of the input file
  #   2. graph                 - Graph instance having the whole input
  #   3. control_table_entries - Array of ControlTable instances
  # Returns: Inconsistent routes for a given route
  #
  # Method to find inconsistent combination for every route
  def find_conflict_paths file_name, graph, control_table_entries
    conflict_routes = {}
    puts "Identofying consistent routes in control table entries for the input file '#{file_name}'"
    # Create an instance of ProgramGenerator to build NuSMV program
    # for model checking two routes
    program_generator = ProgramGenerator.new
    # Get the vertices attribute from graph object
    vertices = graph.get_attribute :vertices
    # Create an instance of Analyzer to build the reasoning
    # for every combination of 2 routes
    analyzer = Analyzer.new
    # A hash instance used to evaluate performance
    # Strictly to be used for sample_layout input only (given by default)
    results = {}

    # Iterate through the control table entries
    # Combination item 1
    control_table_entries.each do |control_table_entry_1|
      # Initialize the value for route 1 to be empty array
      conflict_routes[control_table_entry_1.to_s] = [] if conflict_routes[control_table_entry_1.to_s].nil?
      # Initialize results hash also to be empty array for route 1
      results[control_table_entry_1.to_s] = []
      # Get the signal for the route 1
      signal_1 = control_table_entry_1.get_source_signal
      # Iterate through the control table entries
      # Combination item 2
      control_table_entries.each do |control_table_entry_2|
        exec_path = ""
        # Get the signal for the route 2
        signal_2 = control_table_entry_2.get_source_signal
        if control_table_entry_1.get_point_info && !control_table_entry_2.get_point_info
          # If the route 1 is a point and route 2 is not a point
          # find the routes that have the point status as not same
          # Ex: 65-N point will check for routes that have 65-R
          conflict = compute_conflicts_for_point(control_table_entry_1, control_table_entry_2)
          conflict_routes[control_table_entry_1.to_s] << control_table_entry_2 if conflict
          exec_path = conflict ? "not allowed" : "allowed"
        elsif !are_points_consistent?(control_table_entry_1, control_table_entry_2)
          # If both the routes have same point in contradicting status
          # it is not possible to apply both at the same time
          # Ex: Point 65 is N for route 1 and R for route 2 is not practically
          #     feasible
          exec_path = "PC"
        elsif (control_table_entry_1.to_s != control_table_entry_2.to_s) &&
          !control_table_entry_2.get_point_info

          # If route 1 and 2 are not the same and route 2 is not a point
          if conflict_routes[control_table_entry_1.to_s].include?(control_table_entry_2)
            # If the consistency result has been computed already as
            # inconsistent no need to recompute
            exec_path = "C"
          else
            # If the consistency result has not been computed
            # call the ProgramGenerator class' instance method
            # to compute the consistency
            conflict = program_generator.find_conflict file_name, control_table_entry_1, control_table_entry_2, vertices
            if conflict
              # If inconsistent add the route 2 to route 1's list and
              # vice versa as this is symmetrical
              conflict_routes[control_table_entry_1.to_s] << control_table_entry_2
              conflict_routes[control_table_entry_2.to_s] = [] if conflict_routes[control_table_entry_2.to_s].nil?
              conflict_routes[control_table_entry_2.to_s] << control_table_entry_1
            end
            exec_path = conflict ? "C" : "NC"
          end
        elsif !control_table_entry_2.get_point_info
          # If the route 2 is not a point consistency check is not made
          # This gets true when both the routes are same
          exec_path = "X"
        else
          # If route 1 and 2 are points it is not considered to check
          exec_path = "not considered"
        end
        if exec_path.length > 0 && exec_path.length < 4
          # If the exec_path is a symbol
          # prepare the result and analyzer
          result = {
            "#{control_table_entry_1}_#{control_table_entry_2}" => exec_path
          }
          if signal_1.get_direction == signal_2.get_direction
            result = {Analyzer::Direction::UNI => result}
          else
            result = {Analyzer::Direction::OPP => result}
          end
          result = {signal_2.get_type.to_s => result}
          analyzer.add_category signal_1.get_type.to_s, result
          results[control_table_entry_1.to_s] << exec_path
        end
        puts "  #{control_table_entry_1} - #{control_table_entry_2} : #{exec_path}"
      end
      puts "------------------------------"
    end
    puts "Legends:"
    puts "  X  - With same route, so impossible"
    puts "  NC - No Collision"
    puts "  C  - Collision"
    puts "  PC - Points Conflict"
    puts "------------------------------"
    puts "Identifying consistent routes in control table entries done!"
    file_path = "output/#{file_name.gsub('.', '_')}/temp/"
    # Create the folder if it does not exists
    Dir.mkdir(file_path) unless File.exists? file_path

    # PERFORMANCE EVALUTION METHOD CALL
    # To be uncommented if the input is sample_layout(default)
    # compare_results results, file_name, file_path

    # Write the analyzer results to file
    File.open("#{file_path}output_reasoning.txt", 'w') do |file|
      file.puts analyzer.to_s
    end
    conflict_routes
  end

  private

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tbl_entry_1 - ControlTable instance for route 1(point)
    #   2. ctrl_tbl_entry_2 - ControlTable instance for route 2
    # Returns: Boolean value indicating consistent or inconsistent
    #
    # Method to determine if routes are inconsistent or not
    # true for inconsistent and vice versa
    def compute_conflicts_for_point ctrl_tbl_entry_1, ctrl_tbl_entry_2
      # Get point and its status for route 1
      point_1 = ctrl_tbl_entry_1.get_source_signal
      status_1 = ctrl_tbl_entry_1.get_destination_label == Vertex::PointStatus::MAPPING_SHORT[Vertex::PointStatus::NORMAL]
      # Get locks and detects points for route 2
      lnd_points_2 = ctrl_tbl_entry_2.get_locks_and_detects_points
      # Conditions to check inconsistency
      #   1. The point of route 1 is in the locks and detects of route 2
      #   2. The status of route 1 and route 2 point are not the same
      (!lnd_points_2[point_1].nil?) && (lnd_points_2[point_1].to_s != status_1.to_s)
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. control_table_entry_1 - ControlTable instance for route 1
    #   2. control_table_entry_2 - ControlTable instance for route 2
    # Returns: Boolean value indicating whether the routes' points are same
    #
    # Method to compute whether the routes' points are same or not
    def are_points_consistent? control_table_entry_1, control_table_entry_2
      # Get the locks and detects points for both the routes
      lnd_points_1 = control_table_entry_1.get_locks_and_detects_points
      lnd_points_2 = control_table_entry_2.get_locks_and_detects_points
      # Iterate through the locks and detects points of route 1
      lnd_points_1.each do |point_1, status_1|
        # If the point of route 1 is in locks and detects points of route 2
        # inconsistency has occurred
        if !lnd_points_2[point_1].nil? && (lnd_points_2[point_1] != status_1)
          return false
        end
      end
      return true
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. results   - Hash instance holding the results of inconsistency
    #                  computation
    #   2. file_name - Name of input file
    #   3. file_path - Folder path
    # Returns: NA
    #
    # Method to evaluate the performance of consistency computation for
    # sample_layout input
    #
    # WARNING: If this method is called for anyother input without modifying
    #          the sample_data hash, it may cause problems while executing
    def compare_results results, file_name, file_path
      # Sample data for every route except point
      sample_data = {
          "1A-A" => ["X" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "N" , "Y" , "N" , "N" , "N" , "N" , "Y" , "N" , "N"],
          "1A-A1" => ["N" , "X" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "Y" , "Y" , "Y" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "Y"],
          "1A-B" => ["N" , "N" , "X" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "N" , "N" , "Y" , "N" , "N" , "Y" , "N" , "N" , "N" , "Y" , "N"],
          "1A-C" => ["N" , "N" , "N" , "X" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "Y"],
          "1A-C1" => ["N" , "N" , "N" , "N" , "X" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "Y" , "N" , "Y" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N"],
          "1B-A" => ["Y" , "Y" , "N" , "N" , "N" , "X" , "N" , "N" , "N" , "Y" , "Y" , "N" , "Y" , "N" , "N" , "Y" , "Y" , "Y" , "Y" , "N" , "Y" , "N" , "Y" , "N" , "N" , "N" , "Y" , "Y" , "Y" , "Y"],
          "1B-B" => ["N" , "N" , "Y" , "N" , "N" , "N" , "X" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "N" , "Y" , "Y" , "Y" , "Y"],
          "1B-C" => ["N" , "N" , "N" , "Y" , "Y" , "N" , "N" , "X" , "N" , "N" , "Y" , "N" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "Y" , "Y" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "Y" , "Y"],
          "2-K" => ["N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "X" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "Y" , "N"],
          "3-K" => ["N" , "N" , "N" , "N" , "N" , "Y" , "Y" , "N" , "N" , "X" , "N" , "N" , "Y" , "Y" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "Y" , "N" , "N" , "N" , "Y" , "N" , "N"],
          "6-K" => ["N" , "N" , "N" , "N" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "X" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "Y" , "N" , "N" , "Y"],
          "8-L" => ["N" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "X" , "N" , "N" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "N" , "N" , "Y" , "Y" , "Y" , "Y" , "Y" , "Y" , "Y" , "Y"],
          "9-A" => ["Y" , "Y" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "Y" , "Y" , "N" , "X" , "N" , "N" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "N" , "Y" , "N" , "N" , "N" , "Y" , "Y" , "Y" , "Y"],
          "9-B" => ["N" , "N" , "Y" , "N" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "X" , "N" , "N" , "Y" , "N" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "N" , "Y" , "Y" , "Y" , "Y"],
          "9-C" => ["N" , "N" , "N" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "N" , "Y" , "N" , "N" , "N" , "X" , "N" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "Y" , "Y"],
          "17-A" => ["Y" , "N" , "N" , "N" , "N" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "N" , "N" , "X" , "N" , "N" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "N" , "N" , "N" , "Y" , "N" , "N"],
          "17-B" => ["N" , "Y" , "Y" , "N" , "Y" , "Y" , "Y" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "N" , "N" , "X" , "N" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "N" , "N" , "Y" , "N"],
          "17-C" => ["N" , "Y" , "N" , "Y" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "N" , "X" , "N" , "Y" , "Y" , "N" , "N" , "N" , "N" , "Y" , "Y" , "N" , "N" , "Y"],
          "25-J" => ["Y" , "Y" , "Y" , "Y" , "Y" , "Y" , "Y" , "Y" , "N" , "N" , "N" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "N" , "X" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "N"],
          "27-H" => ["N" , "N" , "N" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "N" , "X" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "Y"],
          "30-H" => ["Y" , "Y" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "X" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "Y" , "Y"],
          "31-H" => ["N" , "N" , "Y" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "X" , "N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N"],
          "32A-A" => ["Y" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "X" , "N" , "N" , "N" , "N" , "Y" , "N" , "N"],
          "32A-A1" => ["N" , "N" , "N" , "N" , "N" , "N" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "N" , "Y" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "X" , "N" , "N" , "N" , "Y" , "N" , "N"],
          "32A-B" => ["N" , "N" , "Y" , "N" , "N" , "N" , "Y" , "N" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "X" , "N" , "N" , "N" , "Y" , "N"],
          "32A-C" => ["N" , "N" , "N" , "Y" , "N" , "N" , "N" , "Y" , "N" , "N" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "X" , "N" , "N" , "N" , "Y"],
          "32A-C1" => ["N" , "N" , "N" , "N" , "N" , "Y" , "Y" , "N" , "N" , "N" , "Y" , "Y" , "Y" , "Y" , "N" , "N" , "N" , "Y" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "N" , "X" , "N" , "N" , "Y"],
          "32B-A" => ["Y" , "N" , "N" , "N" , "N" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "Y" , "N" , "Y" , "N" , "N" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "N" , "N" , "N" , "X" , "N" , "N"],
          "32B-B" => ["N" , "Y" , "Y" , "N" , "Y" , "Y" , "Y" , "Y" , "Y" , "N" , "N" , "Y" , "Y" , "Y" , "Y" , "N" , "Y" , "N" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "N" , "N" , "X" , "N"],
          "32B-C" => ["N" , "Y" , "N" , "Y" , "N" , "Y" , "Y" , "Y" , "N" , "N" , "Y" , "Y" , "Y" , "Y" , "Y" , "N" , "N" , "Y" , "N" , "Y" , "Y" , "N" , "N" , "N" , "N" , "Y" , "Y" , "N" , "N" , "X"]}

      result_data = {}
      questions = ""
      total_count = 0
      inconsistent_count = 0

      puts "Comparing the performance with sample data..."

      # Iterate through sample_data to evaluate performance and ask questions
      # if any inconsistency is found
      sample_data.each do |route, conflicts|
        result_data[route] = []
        conflicts.each_with_index do |conflict, index|
          if conflict == "Y"
            if results[route][index] == "C"
              result_data[route] << "C"
            else
              result_data[route] << "U(C)"
              questions += "How does #{route} and #{results.keys[index]} cause collision?\n"
              inconsistent_count += 1
            end
          elsif conflict == "N"
            if results[route][index] == "NC"
              result_data[route] << "NC"
            elsif results[route][index] == "C"
              result_data[route] << "U(NC)"
              questions += "How does #{route} and #{results.keys[index]} does not cause collision?\n"
              inconsistent_count += 1
            else
              result_data[route] << "PC"
            end
          else
            result_data[route] << "X"
          end
          total_count += 1
        end
      end

      result  = "  #{inconsistent_count} out of #{total_count} entries"
      result += " (#{inconsistent_count * 100 / total_count}%)"
      result += " are inconsistent."
      puts result

      # Generate a CSV file for the consistency result between two routes
      File.open("#{file_path}output_stats.csv", 'w') do |file|
        file.puts ",#{result_data.keys.join(',')}"
        result_data.each do |key, result|
          file.puts "#{key},#{result.join(',')}"
        end
      end

      # Print the questions to a file
      File.open("#{file_path}controversy_questions.txt", 'w') do |file|
        file.puts questions
      end
    end
end