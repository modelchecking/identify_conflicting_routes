=begin
 * Vertex class
 *
 * Class to implement and perform Vertex operations
=end
class Vertex

  # ID of the vertex stored as data
  @data
  # Hash with key denoting the adjacent vertex ID and value as Edge instance
  @adjacents
  # Boolean variable denoting whether the vertex is occupied by a train or not
  @occupied
  # Array of vertices denoting the impossible path to be taken practically
  # by a train
  @blacklisted_path
  # String value denoting the point ID
  @point_id
  # Instance of track denoting the track to which the vertex belongs
  @track
  # Array of labels assigned for a Vertex
  @labels
  # Signal instances
  @signals

  # Constructor method
  def initialize
    # Initializing the attributes according to their class
    @data = nil
    @occupied = false
    @adjacents = {}
    @blacklisted_path = []
    @point_id = nil
    @track = nil
    @labels = []
    @signals = {}
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: String denoting ID of Vertex
  #
  # Method to read the data attribute
  def get_data
    return @data
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: String denoting ID of Vertex
  # Returns: String denoting ID of Vertex
  #
  # Method to write the data attribute
  def set_data= data
    @data = data
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Boolean value denoting occupied or not occupied
  #
  # Method to read the occupied attribute
  def get_occupied
    return @occupied
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. occupied - Boolean value denoting occupied or not occupied
  # Returns: Boolean value denoting occupied or not occupied
  #
  # Method to write the occupied attribute
  def set_occupied= occupied
    @occupied = occupied
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Array of vertex objects denoting the adjacent vertices
  #
  # Method to read the adjacent attribute
  def get_adjacents
    return @adjacents
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. edge - Instance of Edge
  #   2. adjacent - Instance of Vertex
  # Returns: Array of adjacent vertices or nil
  #           If the new adjacent vertex is not already in the list,
  #           array of adjacent vertices will be returned or nil
  #
  # Method to add an adjacent vertex
  def add_adjacent edge, adjacent
    @adjacents[adjacent.get_data] = edge
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. adjacent - Instance of Vertex
  # Returns: Array of adjacent vertices
  #
  # Method to remove an adjacent vertex from the list of adjacent vertices
  def remove_adjacent adjacent
    @adjacents -= [adjacent]
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Array of vertices which form impossible path with the vertex
  #
  # Method to read the blacklisted vertices
  def get_blacklisted_path
    @blacklisted_path
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. blklsted_pth - Array of blacklisted vertex instances
  # Returns: Array of vertices which form impossible path with the vertex
  #
  # Method to write the blacklisted vertex instances
  def add_to_blacklisted_path blklsted_pth
    @blacklisted_path = blklsted_pth
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: ID of point
  #
  # Method to get the point ID
  def get_point
    @point_id
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. point_id - ID of point
  # Returns: ID of point
  #
  # Method to set the point ID
  def set_point= point_id
    @point_id = point_id
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Instance of Track
  #
  # Method to read the track attribute
  def get_track
    return @track
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. track - Instance of track
  # Returns: Instance of Track
  #
  # Method to write the track attribute
  def set_track= track
    @track = track
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Array of String instances denoting labels
  #
  # Method to read the labels
  def get_labels
    @labels
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. label - label ID
  # Returns: Instance of Label
  #
  # Method to find the instance of a label ID
  def get_label label
    @labels.select{|l| l.get_data == label}.first
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. labels - Array of String instances
  # Returns: Array of String instances denoting labels
  #
  # Method to write the labels
  def set_labels= labels
    label_objs = []
    labels.each do |label|
      label_obj = Label.new
      label_parts = label.split('-')
      label_obj.set_data = label_parts[0]
      label_obj.set_platform = (label_parts[1] == "P") unless label_parts[1].nil?
      label_objs << label_obj
    end
    @labels = label_objs
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Array of Signal instances
  #
  # Method to get the array of Signal instances
  def get_signals
    return @signals
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. signal - Instance of Signal
  # Returns: Instance of signal
  #
  #
  def add_signal signal
    @signals[signal.get_data] = signal
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Boolean value denoting if the vertex is a point or not
  #
  # Method to find if the vertex instance is a point or not
  # If the vertex is a point there will be blacklisted vertices
  def is_a_point?
    !@point_id.nil?
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: String denoting the attributes for instance of Vertex
  #
  # Method to get the attributes value of instance of Vertex
  def to_s
    "<Vertex: #{@data}, #{@labels}, #{@signals}>"
  end

  # Module for PointStatus
  # Used to process for point status to be either normal or reverse
  module PointStatus
    NORMAL = true
    REVERSE = false
    MAPPING = {NORMAL => "normal", REVERSE => "reverse"}
    MAPPING_SHORT = {NORMAL => "N", REVERSE => "R"}
  end

  # Scope: Public
  # Type: Class method
  # Parameters:
  #   1. points - Hash instance having key as point ID and its status as value
  # Returns: Array of strings which have key and status in text
  #
  # Method used to print points' status
  def self.display_points points
    status_txt = []
    points.each do |key, value|
      status_txt << "#{key}-#{PointStatus::MAPPING_SHORT[value]}"
    end
    status_txt
  end
end
