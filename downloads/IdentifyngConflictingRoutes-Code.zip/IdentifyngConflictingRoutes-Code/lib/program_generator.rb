=begin
 * ProgramGenerator class
 *
 * Class to build NuSMV models to check consistency between two routes
=end
class ProgramGenerator

  # Constants to be used for NuSMV program generation
  COMMENTS = "-- *****\n-- EVERY ROUTE IS A MODULE. A TRAIN WILL MOVE IN A ROUTE.\n-- *****\n\n"
  DOUBLE_SPACE = "  "
  NEW_LINE = "\n"
  SEMI_COLON = ";#{NEW_LINE}"
  TRUE = "TRUE"
  FALSE = "FALSE"
  VAR_BLOCK = "#{DOUBLE_SPACE}VAR#{NEW_LINE}"
  ASSIGN_BLOCK = "#{DOUBLE_SPACE}ASSIGN#{NEW_LINE}"
  # Synchronous mode:
  #   true will generate NuSMV model as synchronous non-deterministic model
  #   false will generate NuSMV model as asynchronous deterministic model
  SYNCHRONOUS_MODE = true

  # Extra path computed for shunt and calling on home as Hash instance
  @shunt_n_calling_on_home_paths
  # Locks and detects points for extra path of shunt and calling on home as
  # Hash instance
  @lnd_points
  # Modules built for every route as hash instance
  @modules_for_routes

  # Constructor method
  def initialize
    # Initializing the attributes according to their class
    @shunt_n_calling_on_home_paths = {}
    @lnd_points = {}
    @modules_for_routes = {}
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. file_name        - Name of the input file
  #   2. ctrl_tab_entry_1 - ControlTable instance of route 1
  #   3. ctrl_tab_entry_2 - ControlTable instance of route 2
  #   4. vertices         - Hash with vertices ID as key and Vertex instances
  #                         as value
  # Returns: Boolean value indicating whether the routes are inconsistent or
  #          not
  #
  # Method to build NuSMV model and compute if two routes are inconsistent or
  # not
  def find_conflict file_name, ctrl_tab_entry_1, ctrl_tab_entry_2, vertices
    # Check inconsistency for advanced starter as it has only one vertex as
    # path
    status, safety = check_advanced_starter ctrl_tab_entry_1, ctrl_tab_entry_2
    return safety if status
    # Check inconsistency for routes in same direction to be subset of another
    safety = check_unidirectional_subset ctrl_tab_entry_1, ctrl_tab_entry_2
    return !safety if safety
    # Check inconsistency for routes in shunt and different track
    safety = check_opposite_different_track_shunt ctrl_tab_entry_1, ctrl_tab_entry_2
    return !safety if safety
    # Generate NuSMV model and check for inconsistency using NuSMV tool
    file_name_with_path = generate_program file_name, ctrl_tab_entry_1, ctrl_tab_entry_2, vertices
    is_the_combination_safe? file_name_with_path
  end

  private

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. file_name        - Name of the input file
    #   2. ctrl_tab_entry_1 - ControlTable instance for route 1
    #   3. ctrl_tab_entry_2 - ControlTable instance for route 2
    # Returns: The file name with path of NuSMV program developed
    #
    # Method to develop NuSMV program for the combination of routes 1 and 2
    def generate_program file_name, ctrl_tab_entry_1, ctrl_tab_entry_2, vertices
      # Create the file name based on the signal label of both the routes
      program_file_name = "model_#{ctrl_tab_entry_1.to_s}_#{ctrl_tab_entry_2.to_s}.smv"
      # Develop the NuSMV program
      modules  = COMMENTS
      # Build modules for modules of each route
      modules += build_module ctrl_tab_entry_1, vertices
      modules += NEW_LINE
      modules += build_module ctrl_tab_entry_2, vertices
      program  = modules + NEW_LINE
      # Develop the main module
      program += generate_main_module ctrl_tab_entry_1, ctrl_tab_entry_2
      program += NEW_LINE
      # Develop the LTLSPEC to check property
      program += construct_spec ctrl_tab_entry_1, ctrl_tab_entry_2
      create_folder file_name
      file_name_with_path = "#{get_dir_name(file_name, 3)}/#{program_file_name}"
      # Write the NuSMV program to file
      File.open(file_name_with_path, 'w') do |file|
        file.puts program
      end
      file_name_with_path
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. var  - Variable to be used in NuSMV program
    #   2. type - Datatype of variable
    # Returns: String as NuSMV program to declare a variable
    #
    # Method to declare a variable of a datatype
    def declare_var_with_type var, type
      "#{DOUBLE_SPACE * 2}#{var} : #{type}#{SEMI_COLON}"
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. var - Variable to be used in NuSMV program
    #   2. val - Value to initialize the variable with
    # Returns: String as NuSMV program to initialize a variable
    #
    # Method to initialize a variable with a value
    def init_var_with_val var, val
      "#{DOUBLE_SPACE * 2}init(#{var}) := #{val}#{SEMI_COLON}"
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. var - Variable to be used in NuSMV program
    # Returns: String as NuSMV program to define the start of next value
    #
    # Method to set the start of next value of variable
    def next_var var
      "#{DOUBLE_SPACE * 2}next(#{var}) := "
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry - ControlTable instance of a route
    #   2. vertices       - Hash with vertices ID as key and Vertex instance
    #                       as value
    # Returns: String with NuSMV module for a route
    #
    # Method to build the module for a route
    def build_module ctrl_tab_entry, vertices
      if @modules_for_routes[ctrl_tab_entry.to_s]
        # If this route has a module generated already return it
        return @modules_for_routes[ctrl_tab_entry.to_s]
      end
      # Get the source Signal instance
      signal = ctrl_tab_entry.get_source_signal
      module_code = "MODULE route_#{ctrl_tab_entry.to_s.gsub('-', '_')}("
      if signal.get_type == TrainSignal::Type::SHUNT ||
        signal.get_type == TrainSignal::Type::CALLING_ON_HOME

        # If the signal type is calling on home or shunt
        # find the extra path and compute locks and detects points for it
        # Reading about the behavior of train following these two signals is
        # recommended to know the reason
        shunt_n_calling_on_home_path = compute_shunt_n_calling_on_home_vertices_hash ctrl_tab_entry, vertices
        # Get the path as array
        var_values = ControlTableGenerator.compute_path_as_array shunt_n_calling_on_home_path
        # Find the point IDs which are not in route's locks and detects points
        point_params = compute_missing_lnd_points(ctrl_tab_entry).keys
        # Build the missing point IDs to be passed a parameter to the module
        module_code += point_params.map{|point| "point_#{point}"}.join(', ')
      else
        # If the signal type is not calling on home or shunt get the path as
        # array
        var_values = ctrl_tab_entry.get_controlled_by_tracks_array
      end
      module_code += ")#{NEW_LINE}#{VAR_BLOCK}"
      # Build the values for variable as the vertices of path
      var_values = "{#{var_values.map{|var| "#{34.chr}#{var}#{34.chr}"}.join(', ')}}"
      module_code += declare_var_with_type("track_id", var_values)
      module_code += ASSIGN_BLOCK
      # Initialize the variable with source vertex ID
      init_value = "#{34.chr}#{ctrl_tab_entry.get_source_vertex.get_data}#{34.chr}"
      module_code += init_var_with_val("track_id", init_value)
      # Build the transition for variable
      module_code += generate_transitions(ctrl_tab_entry, vertices)
      # Store the generated module code for a route,
      # so that it need not be generated again
      @modules_for_routes[ctrl_tab_entry.to_s] = module_code
      module_code
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry - ControlTable instance for a route
    #   2. vertices       - Hash with vertices ID as key and Vertex instance as
    #                       value
    # Returns: Path for shunt and calling on home as hash instance
    #
    # Method to compute the extra path for shunt and calling on home
    def compute_shunt_n_calling_on_home_vertices_hash ctrl_tab_entry, vertices
      if @shunt_n_calling_on_home_paths[ctrl_tab_entry.to_s].nil?
        # Compute extra path if it has not been computed
        shunt_n_calling_on_home_path = compute_shunt_n_calling_on_home_path ctrl_tab_entry, vertices
        shunt_n_calling_on_home_path_obj = @shunt_n_calling_on_home_paths[ctrl_tab_entry.to_s]
        lnd_point = ControlTableGenerator.new.compute_shunt_n_calling_on_home_xtra_lnd_points(shunt_n_calling_on_home_path_obj, vertices)
        @lnd_points[ctrl_tab_entry.to_s] = lnd_point
        shunt_n_calling_on_home_path
      else
        # If extra path has been already computed return it
        @shunt_n_calling_on_home_paths[ctrl_tab_entry.to_s].get_path
      end
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry - ControlTable instance for a route
    #   2. vertices       - Hash with vertices ID as key and Vertex instance as
    #                       value
    # Returns: Path for shunt and calling on home as hash instance
    #
    # Method to compute the extra path for shunt and calling on home
    def compute_shunt_n_calling_on_home_path ctrl_tab_entry, vertices
      # Get the path computed already as hash for the route
      hash_path = ctrl_tab_entry.get_controlled_by_tracks_hash
      # Get the signal direction
      signal_dir = ctrl_tab_entry.get_source_signal.get_direction
      # Create an instance for Path and set its attributes appropriately
      path = Path.new
      path.set_source_vertex = ctrl_tab_entry.get_source_vertex
      path.set_source_signal = ctrl_tab_entry.get_source_signal
      path.set_destination_label = ctrl_tab_entry.get_destination_label
      # Get the last Vertex instance from ControlTable instance
      vertex = ctrl_tab_entry.get_destination_vertex
      # Get the destination label
      dest_label = path.get_destination_label
      # Compute the path
      new_path = compute_and_add_xtra_path_shunt_n_calling_on_home(vertex, dest_label, false, path)[0]
      # Get the new destination label and set the path attribute
      dest_vertex = (new_path.values - new_path.keys).first
      path.set_destination_vertex = vertices[dest_vertex]
      # Add the newly computed path with previously computed path and set it to
      # path attribute
      shunt_n_calling_on_home_path = hash_path.merge(new_path)
      path.set_path = shunt_n_calling_on_home_path
      # Add the path instance to the instance variable to prevent computing
      # once again
      @shunt_n_calling_on_home_paths[ctrl_tab_entry.to_s] = path
      shunt_n_calling_on_home_path
    end

    # Scope: Private
    # Type: Instance method(recursive)
    # Parameters:
    #   1. vertex        - Vertex instance
    #   2. dest_label    - Destination label ID
    #   3. crossed_label - Boolean value indicating whether the destination
    #                      label has crossed while traversing or not
    # Returns:
    #   1. path          - Path as hash
    #   2. crossed_label - Boolean value indicating whether the destination
    #                      label has crossed while traversing or not
    #
    # Method to compute the extra path for shunt and calling on home using DFS
    def compute_and_add_xtra_path_shunt_n_calling_on_home vertex, dest_label, crossed_label, shunt_n_calling_on_home_path
      next_vertices = []
      # Get the signal direction
      signal_dir = shunt_n_calling_on_home_path.get_source_signal.get_direction
      # Get the next vertices that are adjacent to the vertex in the signal
      # direction
      vertex.get_adjacents.values.select do |edge|
        next_vertex = nil
        if signal_dir == TrainSignal::Direction::UP
          next_vertices << edge.get_up_vertex
        elsif signal_dir == TrainSignal::Direction::DOWN
          next_vertices << edge.get_down_vertex
        end
      end
      # Remove duplicates and the vertex itself
      next_vertices = next_vertices.uniq
      next_vertices -= [vertex]
      path = {}
      # Get the Label instance which has destination label ID
      label = vertex.get_label(dest_label)
      if label
        # If the destination label is found
        # set the crossed_label as true
        crossed_label = true
      end
      # Iterate through the next vertices to make recursive call
      next_vertices.each do |next_vertex|
        temp_path, crossed_label = compute_and_add_xtra_path_shunt_n_calling_on_home(next_vertex, dest_label, crossed_label, shunt_n_calling_on_home_path)
        if crossed_label
          # If the destination label has been crossed
          # prepare the path hash and break the iteration
          path = {vertex.get_data => next_vertex.get_data}
          path.merge!(temp_path)
          break
        end
      end
      return path, crossed_label
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry - ControlTable instance of a route
    # Returns: Hash of point ID as key and its status as value which are not
    #          already computed in module 3
    #
    # Method to find the points that are not computed already in module 3
    def compute_missing_lnd_points ctrl_tab_entry
      # Get the new locks and detects points for the ControlTable instance
      signal_label_lnd_points = @lnd_points[ctrl_tab_entry.to_s]
      # Get the already computed locks and detects points for the ControlTable
      # instance
      lnd_points = ctrl_tab_entry.get_locks_and_detects_points
      # Select the points that are newly computed
      signal_label_lnd_points.select{ |key, value| lnd_points[key].nil? }
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry - ControlTable instance for a route
    #   2. vertices       - Hash with vertices ID as key and Vertex instance as
    #                       value
    # Returns: String as NuSMV program for transition of values for module
    #          variable
    #
    # Method to build the transition for module variable
    def generate_transitions ctrl_tab_entry, vertices
      # Get the source Signal instance
      signal = ctrl_tab_entry.get_source_signal
      shunt_n_calling_on_home = [TrainSignal::Type::SHUNT, TrainSignal::Type::CALLING_ON_HOME].include?(signal.get_type)
      if shunt_n_calling_on_home
        # If the signal is shunt and calling on home type
        # get newly computed locks and detects points and path hash
        lnd_point = @lnd_points[ctrl_tab_entry.to_s]
        path_hash = @shunt_n_calling_on_home_paths[ctrl_tab_entry.to_s].get_path
      else
        # If the signal is not shunt and calling on home
        # get the locks and detects points and path hash from ControlTable
        # instance
        lnd_point = ctrl_tab_entry.get_locks_and_detects_points
        path_hash = ctrl_tab_entry.get_controlled_by_tracks_hash
      end
      transitions = "#{next_var("track_id")}case#{NEW_LINE}"
      # Get the source vertex ID from path
      vertex = (path_hash.keys - path_hash.values).first
      prev_vertex = nil
      next_vertex = nil
      # Iterate till there is a path
      while vertex
        if prev_vertex
          # If previous vertex is there
          # develop the transition code
          transitions += DOUBLE_SPACE * 12
          transitions += "track_id = #{34.chr}#{prev_vertex}#{34.chr}"
          if next_vertex && shunt_n_calling_on_home
            # Get locks and detects points to check for applying
            # point condition to transition
            lnd_points = ctrl_tab_entry.get_locks_and_detects_points
            point_condition = get_point_condition vertices, prev_vertex, vertex, next_vertex, lnd_points
            transitions += point_condition
          end
          if SYNCHRONOUS_MODE
            # If SYNCHRONOUS_MODE is true
            # set the values as a set
            next_values =  "{#{34.chr}#{prev_vertex}#{34.chr}, "
            next_values += "#{34.chr}#{vertex}#{34.chr}}"
          else
            # If SYNCHRONOUS_MODE is false
            # set the next value
            next_values = "#{34.chr}#{vertex}#{34.chr}"
          end
          transitions += " : #{next_values}#{SEMI_COLON}"
        end
        prev_vertex = vertex
        vertex = path_hash[vertex]
        next_vertex = path_hash[vertex]
      end
      transitions += "#{DOUBLE_SPACE * 12}TRUE : track_id#{SEMI_COLON}"
      transitions += "#{DOUBLE_SPACE * 11}esac#{SEMI_COLON}"
      transitions
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. vertices    - Hash with vertices ID as key and Vertex instance as
    #                    value
    #   2. prev_vertex - Previous Vertex instance
    #   3. vertex      - Vertex instance
    #   4. next_vertex - Next Vertex instance
    #   5. lnd_points  - Locks and detects points as hash
    # Returns: String as NuSMV condition for transition
    #
    # Method to check if point status is required for making a transition
    def get_point_condition vertices, prev_vertex, vertex, next_vertex, lnd_points
      condition = ""
      # Get the Vertex, previous Vertex and next Vertex instance
      vertex_obj = vertices[vertex]
      prev_vertex_obj = vertices[prev_vertex]
      next_vertex_obj = vertices[next_vertex]
      if vertex_obj.is_a_point? && next_vertex_obj.get_point != vertex_obj.get_point &&
        lnd_points[vertex_obj.get_point].nil?

        # If vertex is a point and the point of vertex
        # and next vertex are not the same
        # and locks and detects points of vertex is nil
        # set the condition
        condition += " & "
        if prev_vertex_obj.get_point == vertex_obj.get_point
          # If the previous vertex and vertex have the same point ID
          # negate the condition
          condition += "!"
        end
        condition += "point_#{vertex_obj.get_point}"
      end
      if condition.length > 0 && vertex_obj.get_blacklisted_path.map(&:get_data).include?(prev_vertex) && prev_vertex_obj.get_point != vertex_obj.get_point
        # If the condition was set
        # and the previous vertex and vertex follows a blacklisted path
        # and previous vertex and vertex have different point ID
        # remove the condition
        condition = ""
      end
      condition
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry_1 - ControlTable instance for route 1
    #   2. ctrl_tab_entry_2 - ControlTable instance for route 2
    # Returns: String as NuSMV program for main module
    #
    # Method to develop main module for NuSMV program
    def generate_main_module ctrl_tab_entry_1, ctrl_tab_entry_2
      main_module  = "MODULE main()#{NEW_LINE}"
      main_module += VAR_BLOCK
      # Get the points and statuses for both the routes
      # It is present only for routes following shunt and calling on home
      # signal types
      point_vars_1 = compute_point_vars ctrl_tab_entry_1
      point_vars_2 = compute_point_vars ctrl_tab_entry_2
      # Declare the point variables
      main_module += declare_points(point_vars_1.keys, point_vars_2.keys)
      # Make module calls with their parameters
      main_module += make_parameters_to_pass ctrl_tab_entry_1, point_vars_1
      main_module += make_parameters_to_pass ctrl_tab_entry_2, point_vars_2

      if point_vars_1.any? || point_vars_2.any?
        # If there are any point variables
        # choose their value that are already computed in module 3 for the
        # other route and initialize and define their transition to be the same
        main_module += ASSIGN_BLOCK
        lnd_points_1 = ctrl_tab_entry_1.get_locks_and_detects_points
        lnd_points_2 = ctrl_tab_entry_2.get_locks_and_detects_points
        point_vars = {}
        point_vars_1.each do |point, status|
          if !lnd_points_2[point].nil?
            # If the point ID is already computed for route 2
            # use its status
            point_vars[point] = lnd_points_2[point]
          else
            # If the point ID was not already computed
            # use the newly computed status
            point_vars[point] = status
          end
        end
        point_vars_2.each do |point, status|
          if point_vars[point].nil?
            # If the point is given by route 1 above
            # do nothing
            # This allows route 1 to take dominance over route 2
            if !lnd_points_1[point].nil?
              # If the point ID is already computed for route 1
              # use its status
              point_vars[point] = lnd_points_1[point]
            else
              # If the point ID was not already computed
              # use the newly computed status
              point_vars[point] = status
            end
          end
        end
        # Declare all the variables
        point_vars.each do |point, status|
          main_module += init_var_with_val("point_#{point}", status.to_s.upcase)
        end
        # Define the transition for variables
        point_vars.keys.each do |point|
          main_module += "#{next_var("point_#{point}")}point_#{point}#{SEMI_COLON}"
        end
      end
      main_module
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry - ControlTable instance for a route
    # Returns: Point variables as hash
    #
    # Method to find the point variables to be used in main module
    def compute_point_vars ctrl_tab_entry
      point_vars = {}
      if [TrainSignal::Type::SHUNT, TrainSignal::Type::CALLING_ON_HOME].include?(ctrl_tab_entry.get_source_signal.get_type)

        # If the signal type is shunt and calling on home
        # find the locks and detects points which are computed new
        point_vars = compute_missing_lnd_points ctrl_tab_entry
      end
      return point_vars
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. point_vars_1 - Points and its statuses as hash
    #   2. point_vars_2 - Points and its statuses as hash
    # Returns: String as NuSMV program to declare the points
    #
    # Method to declare points in NuSMV program
    def declare_points point_vars_1, point_vars_2
      declared_points = ""
      point_vars = (point_vars_1 + point_vars_2).uniq
      # Declare all the points once
      point_vars.each do |point_var|
        declared_points += declare_var_with_type("point_#{point_var}", "boolean")
      end
      declared_points
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry - ControlTable instance for a route
    #   2. point_vars     - Points and statuses as hash
    # Returns: Method to develop NuSMV program to call modules with points as
    #          parameters
    #
    # Method to develop NuSMV code for calling modules with parameters
    def make_parameters_to_pass ctrl_tab_entry, point_vars
      point_params  = "#{DOUBLE_SPACE * 2}train_#{ctrl_tab_entry.to_s.gsub('-', '_')} : "
      if !SYNCHRONOUS_MODE
        # If SYNCHRONOUS_MODE is false
        # add process keyword of NuSMV for making it asynchronous
        point_params += "process "
      end
      point_params += "route_#{ctrl_tab_entry.to_s.gsub('-', '_')}("
      # Add point variables as parameters to call the module for a route
      point_params  + "#{point_vars.keys.map{|p| "point_#{p}"}.join(', ')})#{SEMI_COLON}"
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry_1 - ControlTable instance for route 1
    #   2. ctrl_tab_entry_2 - ControlTable instance for route 2
    # Returns: String as NuSMV code to do LTLSPEC property checking
    #
    # Method to develop LTLSPEC to do property check
    def construct_spec ctrl_tab_entry_1, ctrl_tab_entry_2
      spec  = "LTLSPEC#{NEW_LINE}"
      # Condition to check if two routes do not collide "always"
      spec += "#{DOUBLE_SPACE}G !(train_#{ctrl_tab_entry_1.to_s.gsub('-', '_')}.track_id = "
      spec  + "train_#{ctrl_tab_entry_2.to_s.gsub('-', '_')}.track_id)#{SEMI_COLON}"
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. file_name - Name of the input file
    # Returns: NA
    #
    # Method to create folder for storing NuSMV programs
    def create_folder file_name
      (1..3).each do |level|
        dir_name = get_dir_name file_name, level
        # Create directory if it does not exists
        Dir.mkdir(dir_name) unless File.exists? dir_name
      end
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. file_name - Name of the input file
    #   2. level     - Level of folder depth
    # Returns: Directory path
    #
    # Method to get the directory path based on depth
    def get_dir_name file_name, level
      case level
        when 1
          "output"
        when 2
          "output/#{file_name.gsub('.', '_')}"
        when 3
          "output/#{file_name.gsub('.', '_')}/NuSMV"
      end
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. file_name_with_path - Name of NuSMV program with directory path
    # Returns: Boolean value denoting if the property has failed or not
    #
    # Method to check if the property specified in the NuSMV program has
    # failed or not
    def is_the_combination_safe? file_name_with_path
      # Terminal command to run the NuSMV program
      raw_output = `NuSMV #{file_name_with_path}`
      # Strip off the unnecessary text
      spec = raw_output.split('-- specification')
      result = spec[1].split('is')[1].strip
      # Extract the result of LTL specification
      refined_result = result.split('e')[0] + 'e'
      # Convert the Boolean value in string to Boolean
      refined_result == false.to_s
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry_1 - ControlTable instance for route 1
    #   2. ctrl_tab_entry_2 - ControlTable instance for route 2
    # Returns: Boolean value denoting if the routes cause inconsistency or not
    #
    # Method to check inconsistency when one or both the routes follow
    # advanced starter
    def check_advanced_starter ctrl_tab_entry_1, ctrl_tab_entry_2
      # Get the Signal instance of both the routes
      signal_1 = ctrl_tab_entry_1.get_source_signal
      signal_2 = ctrl_tab_entry_2.get_source_signal
      status = false
      safety = false
      if signal_1.get_type == TrainSignal::Type::ADVANCED_STARTER
        # If the signal type of route 1 is advanced starter
        status = true
        if signal_2.get_type == TrainSignal::Type::SHUNT
          # If the signal type of route 2 is shunt
          # it is inconsistent if the routes are in opposite direction
          safety = signal_1.get_direction != signal_2.get_direction
        else
          # If the signal type of route 2 is not shunt
          # compute advanced starter safety
          safety = compute_advanced_starter_safety ctrl_tab_entry_1, ctrl_tab_entry_2
        end
      elsif signal_2.get_type == TrainSignal::Type::ADVANCED_STARTER
        # If the signal type of route 2 is advanced starter
        status = true
        if signal_1.get_type == TrainSignal::Type::SHUNT
          # If the signal type of route 1 is shunt
          # it is inconsistent if the routes are in opposite direction
          safety = signal_1.get_direction != signal_2.get_direction
        else
          # If the signal type of route 1 is not shunt
          # compute advanced starter safety
          safety = compute_advanced_starter_safety ctrl_tab_entry_2, ctrl_tab_entry_1
        end
      end
      return status, safety
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. cte_adv_strtr - ControlTable instance of route following
    #                      advanced starter
    #   2. cte           - ControlTable instance of a route
    # Returns: Boolean value denoting if there is inconsistency or not
    #
    # Method to check inconsistency for advanced starter route
    def compute_advanced_starter_safety cte_adv_strtr, cte
      # Get the path for route as hash
      path_hash = cte.get_controlled_by_tracks_hash
      # Get the path vertices as array
      vertices_new = ControlTableGenerator.compute_path_as_array path_hash
      # Get the vertex which is the path for advanced starter
      adv_starter_vertex = cte_adv_strtr.get_controlled_by_tracks_hash.keys.first
      # Check if the vertices of other route contains the vertex of
      # advanced starter route
      vertices_new.include?(adv_starter_vertex)
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry_1 - ControlTable instance for route 1
    #   2. ctrl_tab_entry_2 - ControlTable instance for route 2
    # Returns: Boolean value indicating if a route is subset of another
    #          provided both are for same direction
    #
    # Method to check subset of path for routes in same direction
    def check_unidirectional_subset ctrl_tab_entry_1, ctrl_tab_entry_2
      # Get the Signal instance of both the routes
      signal_1 = ctrl_tab_entry_1.get_source_signal
      signal_2 = ctrl_tab_entry_2.get_source_signal
      if signal_1.get_direction == signal_2.get_direction &&
        ((signal_1.get_type == TrainSignal::Type::HOME &&
            signal_2.get_type == TrainSignal::Type::STARTER) ||
          (signal_2.get_type == TrainSignal::Type::HOME &&
            signal_1.get_type == TrainSignal::Type::STARTER))

        # If both the routes are in same direction
        # and one signal type is home and the other is starter
        # check for subset of paths
        path_1 = ctrl_tab_entry_1.get_controlled_by_tracks_hash
        vertices_1 = ControlTableGenerator.compute_path_as_array path_1
        path_2 = ctrl_tab_entry_2.get_controlled_by_tracks_hash
        vertices_2 = ControlTableGenerator.compute_path_as_array path_2
        return check_arrays_subset vertices_1, vertices_2
      end
      false
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. array_1 - Array of vertices for route 1
    #   2. array_2 - Array of vertices for route 2
    # Returns: Boolean value indicating if path of a route is subset of
    #          another route
    #
    # Method to check an array is a subset of another array or not
    def check_arrays_subset array_1, array_2
      # Find the common elements between both arrays
      intersection_array = array_1 & array_2
      # Find the shorter array to check for subset
      short_array = (array_1.length < array_2.length) ? array_1 : array_2
      # Check if the elements of shorter array are in the intersection array
      !short_array.map{|element| intersection_array.include?(element)}.include?(false)
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. ctrl_tab_entry_1 - ControlTable instance for route 1
    #   2. ctrl_tab_entry_2 - ControlTable instance for route 2
    # Returns: Boolean value denoting inconsistency for routes following shunt
    #          signal and heading to different tracks
    #
    # Method to check inconsistency for routes following shunt and heading to
    # different tracks
    def check_opposite_different_track_shunt ctrl_tab_entry_1, ctrl_tab_entry_2
      # Get the Signal instance of both the routes
      signal_1 = ctrl_tab_entry_1.get_source_signal
      signal_2 = ctrl_tab_entry_2.get_source_signal
      if signal_1.get_type == TrainSignal::Type::SHUNT &&
        signal_2.get_type == signal_1.get_type &&
        signal_1.get_direction != signal_2.get_direction &&
        ctrl_tab_entry_1.get_destination_label != ctrl_tab_entry_2.get_destination_label

        # If both the routes are following shunt signal
        # and their direction is opposite
        # and their destination label is different
        # it causes inconsistency
        return true
      end
      false
    end
end