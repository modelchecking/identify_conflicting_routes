=begin
 * ControlTableGenerator class
 *
 * Class to generate the control table entries
=end
class ControlTableGenerator

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. file_name - Name of input file
  #   2. graph     - Instance of graph which has whole of input data
  #   3. paths     - Array of path instances
  # Returns: Array of control table entries
  #
  # Method to compute the state of points for all given paths
  def generate_control_table file_name, graph, paths
    control_table_entries = []
    puts "Generating control table for the input file '#{file_name}'"

    # Get the required attributes from graph
    signals = graph.get_attribute :signals
    vertices = graph.get_attribute :vertices
    tracks = graph.get_attribute :tracks
    terminals = graph.get_attribute :terminals
    labels = graph.get_attribute :labels

    # Iterate through the paths to compute the point statuses
    paths.each do |path|
      # Create a ControlTable instance and set the attributes appropriately
      control_table = ControlTable.new
      control_table.set_source_vertex = path.get_source_vertex
      control_table.set_destination_vertex = path.get_destination_vertex
      control_table.set_source_signal = path.get_source_signal
      control_table.set_destination_label = path.get_destination_label
      control_table.set_controlled_by_tracks_hash = path.get_path

      signal = path.get_source_signal

      puts "  Generating control table entry for #{control_table.to_s}"
      lnd_points = case signal.get_type
          when TrainSignal::Type::HOME
            # Compute Locks and detects points field for home signal type
            compute_lnd_points_home path, vertices
          when TrainSignal::Type::CALLING_ON_HOME
            # Compute Locks and detects points field for calling on home
            # signal type
            dest_label = path.get_destination_label
            # As path was not computed for calling on home signal type
            # in the previous module, it is computed here to be used for
            # internal computations
            routes_gen = RouteGenerator.new
            routes_gen.set_attributes path.get_source_signal.get_direction, dest_label
            src_vertex = routes_gen.get_next_vertex path.get_source_signal.get_vertex
            control_table.set_source_vertex = src_vertex
            computed_path = routes_gen.get_calling_on_home_path src_vertex
            dest_vertex = (computed_path.values - computed_path.keys).first
            dest_vertex = vertices[dest_vertex]
            control_table.set_destination_vertex = dest_vertex
            # The computed path is stored as hash only and not as array
            # since array is what gets displayed in the final output
            # and hash is used in internal computations
            control_table.set_controlled_by_tracks_hash = computed_path
            compute_lnd_points_calling_on_home src_vertex, computed_path, vertices
          when TrainSignal::Type::STARTER
            # Compute Locks and detects points field for starter signal type
            compute_lnd_points_starter path, vertices
          when TrainSignal::Type::SHUNT
            # Compute Locks and detects points field for shunt signal type
            compute_lnd_points_shunt_n_calling_on_home path, vertices
          when TrainSignal::Type::ADVANCED_STARTER
            # No need to compute points statuses for advanced starter signal
            # type
            {}
        end
      if signal.get_type != TrainSignal::Type::CALLING_ON_HOME
        # Convert path from hash to array for all signals except
        # calling on home
        path_hash = control_table.get_controlled_by_tracks_hash
        path_array = ControlTableGenerator.compute_path_as_array path_hash
        control_table.set_controlled_by_tracks_array = path_array
      end
      # Set the attribute for point statuses and add it to the array
      control_table.set_locks_and_detects_points = lnd_points

      puts "  Generating control table entry for #{control_table.to_s} done!"
      control_table_entries << control_table
    end

    points_entry = {}
    # Iterate through every vertex which is a point and
    # add those vertices which are point to its ID as hash
    vertices.each do |v_id, vertex|
      if vertex.is_a_point?
        if points_entry[vertex.get_point].nil?
          points_entry[vertex.get_point] = [vertex.get_data]
        elsif points_entry[vertex.get_point] &&
          !points_entry[vertex.get_point].include?(vertex.get_data)

          points_entry[vertex.get_point] << vertex.get_data
        end
      end
    end
    # Make a ControlTable instance for every state of a point in the input
    # and add the vertices that have it as point to the controlled by tracks
    # attribute
    points_entry.each do |point, point_vertices|
      (1..2).each do |n|
        control_table = ControlTable.new
        control_table.set_point_info = true
        control_table.set_source_signal = point
        control_table.set_destination_label = Vertex::PointStatus::MAPPING_SHORT[n % 2 != 0]
        puts "  Generating control table entry for #{control_table.to_s}"
        control_table.set_controlled_by_tracks_array = point_vertices
        control_table.set_locks_and_detects_points = {}
        control_table_entries << control_table
        puts "  Generating control table entry for #{control_table.to_s} done!"
      end
    end

    puts "Generating control table for the input file '#{file_name}' done"
    return control_table_entries
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. path_hash - Path as hash
  # Returns: Path as array
  #
  # Method to convert path as hash to array
  def self.compute_path_as_array path_hash
    (path_hash.keys + path_hash.values).uniq
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. path     - Instance of path
  #   2. vertices - Hash with vertices ID as key and Vertex instance as value
  # Returns: Point statuses as hash
  #
  # Method to compute point statuses for extra path in case of
  # shunt and calling on home signal type
  def compute_shunt_n_calling_on_home_xtra_lnd_points path, vertices
    compute_lnd_points_shunt_n_calling_on_home path, vertices
  end

  private

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. path     - Path instance for a route
    #   2. vertices - Hash with vertices ID as key and Vertex instance as value
    # Returns: Locks and detects points for home signal type as hash
    #
    # Method to compute the locks and detects points for home signal type route
    def compute_lnd_points_home path, vertices
      lnd_points = {}
      # Get the source and destination vertex of route
      vertex = path.get_source_vertex.get_data
      dest_vertex = path.get_destination_vertex.get_data
      prev_vertex_obj = nil
      vertex_obj = nil
      route_path = path.get_path
      # Traverse through the computed path until the destination vertex is
      # reached
      while vertex != dest_vertex
        # Get previous Vertex instance
        prev_vertex_obj = vertex_obj
        # Get the next vertex ID to traverse and its instance
        vertex = route_path[vertex]
        vertex_obj = vertices[vertex]
        if prev_vertex_obj
          # If previous Vertex instance is not nil
          # compute points' statuses
          if prev_vertex_obj.get_track.get_data != vertex_obj.get_track.get_data &&
            prev_vertex_obj.get_point == vertex_obj.get_point

            # If previous vertex and vertex are not on same track
            # and previous vertex and vertex have same point ID
            # the point is in reverse(R)
            lnd_points.merge!({vertex_obj.get_point => Vertex::PointStatus::REVERSE})
          elsif prev_vertex_obj.get_track.get_data == vertex_obj.get_track.get_data &&
            prev_vertex_obj.is_a_point? && lnd_points[prev_vertex_obj.get_point].nil?

            # If previous vertex and vertex are on same track
            # and previous vertex is a point
            # and previous vertex's point has not been set previously
            # the point is in normal(N)
            lnd_points.merge!({prev_vertex_obj.get_point => Vertex::PointStatus::NORMAL})
          end
        end
      end
      if vertex_obj.is_a_point? && lnd_points[vertex_obj.get_point].nil?
        # If vertex is a point and its point ID has been set previously
        # set the point as normal(N)
        lnd_points.merge!({vertex_obj.get_point => Vertex::PointStatus::NORMAL})
      end
      return lnd_points
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. src_vertex - Source Vertex instance
    #   2. path       - Path instance for a route
    #   3. vertices   - Hash with vertices ID as key and Vertex instance
    # Returns: Locks and detects points for calling on home signal type as hash
    #
    # Method to compute the locks and detects points for calling on home
    # signal type
    def compute_lnd_points_calling_on_home src_vertex, path, vertices
      lnd_points = {}
      # Get the source vertex ID of route
      vertex = src_vertex.get_data
      vertex_obj = nil
      prev_vertex_obj = nil
      # Traverse through the computed path till there is a path
      # In Ruby, value of a key which is not present in a hash will be nil
      while path[vertex]
        # Get the previous Vertex instance
        prev_vertex_obj = vertex_obj
        # Get the next vertex ID to traverse and its instance
        vertex = path[vertex]
        vertex_obj = vertices[vertex]
        if prev_vertex_obj
          # If previous vertex is not nil
          # compute points' statuses
          if prev_vertex_obj.get_track.get_data != vertex_obj.get_track.get_data &&
            prev_vertex_obj.get_point == vertex_obj.get_point

            # If previous vertex and vertex are not on same track
            # and previous vertex and vertex have same point ID
            # the point is in reverse(R)
            lnd_points.merge!({vertex_obj.get_point => Vertex::PointStatus::REVERSE})
          elsif prev_vertex_obj.get_track.get_data == vertex_obj.get_track.get_data &&
            prev_vertex_obj.is_a_point? && lnd_points[prev_vertex_obj.get_point].nil?

            # If previous vertex and vertex are on same track
            # and previous vertex is a point
            # and previous vertex's point has not been set previously
            # the point is in normal(N)
            lnd_points.merge!({prev_vertex_obj.get_point => Vertex::PointStatus::NORMAL})
          end
        end
      end
      return lnd_points
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. src_vertex - Source Vertex instance
    #   2. path       - Path instance for a route
    #   3. vertices   - Hash with vertices ID as key and Vertex instance
    # Returns: Locks and detects points for starter signal type as hash
    #
    # Method to compute the locks and detects points for starter signal type
    def compute_lnd_points_starter path, vertices
      lnd_points = {}
      # Get the source and destination vertex ID
      vertex = path.get_source_vertex.get_data
      dest_vertex = path.get_destination_vertex.get_data
      prev_vertex_obj = nil
      vertex_obj = vertices[vertex]
      route_path = path.get_path
      # Traverse through the computed path until the destination vertex is
      # reached
      while vertex != dest_vertex
        # Get the previous vertex instance
        prev_vertex_obj = vertex_obj
        # Get the next vertex ID to traverse and its instance
        vertex = route_path[vertex]
        vertex_obj = vertices[vertex]
        if prev_vertex_obj
          # If previous vertex is not nil
          # compute points' statuses
          if prev_vertex_obj.get_track.get_data != vertex_obj.get_track.get_data &&
            prev_vertex_obj.get_point == vertex_obj.get_point

            # If previous vertex and vertex are not on same track
            # and previous vertex and vertex have same point ID
            # the point is in reverse(R)
            lnd_points.merge!({vertex_obj.get_point => Vertex::PointStatus::REVERSE})
          elsif prev_vertex_obj.get_track.get_data == vertex_obj.get_track.get_data &&
            prev_vertex_obj.is_a_point? && lnd_points[prev_vertex_obj.get_point].nil?

            # If previous vertex and vertex are on same track
            # and previous vertex is a point
            # and previous vertex's point has not been set previously
            # the point is in normal(N)
            lnd_points.merge!({prev_vertex_obj.get_point => Vertex::PointStatus::NORMAL})
          end
        end
      end
      return lnd_points
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. src_vertex - Source Vertex instance
    #   2. path       - Path instance for a route
    #   3. vertices   - Hash with vertices ID as key and Vertex instance
    # Returns: Locks and detects points for shunt and calling on home signal
    # type as hash
    #
    # Method to compute the locks and detects points for shunt and
    # calling on home signal type as hash
    # Used for computing with extra path in fourth module
    def compute_lnd_points_shunt_n_calling_on_home path, vertices
      lnd_points = {}
      vertex = path.get_source_vertex.get_data
      dest_vertex = path.get_destination_vertex.get_data
      prev_vertex_obj = nil
      vertex_obj = vertices[vertex]
      route_path = path.get_path
      while vertex != dest_vertex
        # Get the previous vertex instance
        prev_vertex_obj = vertex_obj
        # Get the next vertex ID to traverse and its instance
        vertex = route_path[vertex]
        vertex_obj = vertices[vertex]
        if prev_vertex_obj
          # If previous vertex is not nil
          # compute points' statuses
          if prev_vertex_obj.get_track.get_data != vertex_obj.get_track.get_data &&
            prev_vertex_obj.get_point == vertex_obj.get_point

            # If previous vertex and vertex are not on same track
            # and previous vertex and vertex have same point ID
            # the point is in reverse(R)
            lnd_points.merge!({vertex_obj.get_point => Vertex::PointStatus::REVERSE})
          elsif prev_vertex_obj.get_track.get_data == vertex_obj.get_track.get_data &&
            prev_vertex_obj.is_a_point? && lnd_points[prev_vertex_obj.get_point].nil?

            # If previous vertex and vertex are on same track
            # and previous vertex is a point
            # and previous vertex's point has not been set previously
            # the point is in normal(N)
            lnd_points.merge!({prev_vertex_obj.get_point => Vertex::PointStatus::NORMAL})
          end
        end
      end
      if vertex_obj.is_a_point? && lnd_points[vertex_obj.get_point].nil?
        lnd_points.merge!({vertex_obj.get_point => Vertex::PointStatus::NORMAL})
      end
      return lnd_points
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. label  - Label ID
    #   2. labels - Hash instance with label ID as key and Vertex instance as
    #               value
    # Returns: Boolean value denoting if the label is not for platform
    #
    # Method to check if a label is not for platform
    def is_non_platform_label? label, labels
      # Get the Vertex instance of the label ID
      vertex = labels[label]
      # Get the Label instance for the label ID from the Vertex instance
      v_label = vertex.get_label(label)
      !v_label.get_platform
    end
end