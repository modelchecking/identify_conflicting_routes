=begin
 * Path class
 *
 * Class to implement and perform Path operations
=end
class Path

  # Vertex instance denoting source
  @source_vertex
  # Vertex instance denoting destination
  @destination_vertex
  # Signal instance denoting source
  @source_signal
  # Label instance denoting destination
  @destination_label
  # Array of Hash denoting path from source to destination
  @path

  # Constructor method
  def initialize
    # Initializing the attributes according to their class
    @source_vertex = nil
    @destination_vertex = nil
    @source_signal = nil
    @destination_label = nil
    @path = {}
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Instance of Vertex
  #
  # Method to read the source attribute
  def get_source_vertex
    return @source_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. source - Instance of Vertex
  # Returns: Instance of Vertex
  #
  # Method to write the source attribute
  def set_source_vertex= source_vertex
    @source_vertex = source_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Instance of Vertex
  #
  # Method to read the source attribute
  def get_source_signal
    return @source_signal
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. source - Instance of Vertex
  # Returns: Instance of Vertex
  #
  # Method to write the source attribute
  def set_source_signal= source_signal
    @source_signal = source_signal
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Instance of Vertex
  #
  # Method to read the source attribute
  def get_destination_label
    return @destination_label
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. source - Instance of Vertex
  # Returns: Instance of Vertex
  #
  # Method to write the source attribute
  def set_destination_label= destination_label
    @destination_label = destination_label
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Instance of Vertex
  #
  # Method to read the destination attribute
  def get_destination_vertex
    return @destination_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. destination - Instance of Vertex
  # Returns: Instance of Vertex
  #
  # Method to write the source attribute
  def set_destination_vertex= destination_vertex
    @destination_vertex = destination_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Array of Hash denoting the paths between source and destination
  #
  # Method to read the paths attribute
  def get_path
    return @path
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. path - Array of Hash denoting the paths between source and destination
  # Returns: Array of Hash denoting the paths between source and destination
  #
  # Method to access the source attribute
  def set_path= path
    @path = path
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: String denoting the attributes for instance of Path
  #
  # Method to get the attributes value of instance of Path
  def to_s
    "<Path source: #{@source_vertex}, destination: #{@destination_vertex}, paths: #{@path}>"
  end
end