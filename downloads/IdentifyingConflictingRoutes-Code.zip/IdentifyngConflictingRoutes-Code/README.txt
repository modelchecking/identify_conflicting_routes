Install Ruby (atleast 1.9.3) and run the following command from terminal after changing the directory to the directory of this file:
ruby start.rb
