=begin
 * Interface class
 *
 * Class to take care of I/O operations
=end
class Interface

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. file_name - name of input file
  # Returns: NA
  #
  # Method to read input from the input file
  # The different sections to be read from the file are:
  # 1. Railway section layout as graph
  # 2. Impossible paths to take
  # 3. Track segments info
  # 4. UP and DOWN terminals for a path
  def read_input file_name
    puts "Reading the input from #{file_name} file"
    # Create an instance for the Graph class
    graph = Graph.new
    # Open the input file to read data
    file_in = File.new("input/#{file_name}", "r")

    # Reading section layout as graph
    puts "  Reading section layout"
    file_input = file_in.gets.chomp
    # Read from the input file until 'END' is read (case-sensitive)
    while file_input != 'END'
      vertices = file_input.split(' ')
      graph.add_edge vertices[0], vertices[1]
      file_input = file_in.gets.chomp
    end
    puts "  Reading section layout done!"

    # Reading impossible paths
    puts "  Reading impossible paths through the given graph"
    file_input = file_in.gets.chomp
    # Read from the input file until 'END' is read (case-sensitive)
    while file_input != 'END'
      graph.add_point_path file_input.split(' ')
      file_input = file_in.gets.chomp
    end
    puts "  Reading impossible paths through the given graph done!"

    # Reading signal details
    puts "  Reading signal details"
    file_input = file_in.gets.chomp
    # Read from the input file until 'END' is read (case-sensitive)
    while file_input != 'END'
      graph.add_signal_info file_input
      file_input = file_in.gets.chomp
    end
    puts "  Reading signal details done!"

    # Reading the labels of track segments
    puts "  Reading track labels"
    file_input = file_in.gets.chomp
    # Read from the input file until 'END' is read (case-sensitive)
    while file_input != 'END'
      graph.add_label file_input
      file_input = file_in.gets.chomp
    end
    puts "  Reading track labels done!"

    # Reading the track segments info
    puts "  Reading the track segments info"
    file_input = file_in.gets.chomp
    # Read from the input file until 'END' is read (case-sensitive)
    while file_input != 'END'
      graph.add_track_info file_input
      file_input = file_in.gets.chomp
    end
    puts "  Reading the track segments info done!"

    # Reading the terminal points
    puts "  Reading the terminals for path generation"
    file_input = file_in.gets.chomp
    # Read from the input file until 'END' is read (case-sensitive)
    while file_input != nil
      file_input = file_input.chomp
      graph.add_terminals file_input
      file_input = file_in.gets
    end
    puts "  Reading the terminals for path generation done!"
    puts "Reading the input done!"
    # Method to display the details which were read from the input file
    # graph.display_graph
    # Close the input file
    file_in.close

    return graph
  end
end
