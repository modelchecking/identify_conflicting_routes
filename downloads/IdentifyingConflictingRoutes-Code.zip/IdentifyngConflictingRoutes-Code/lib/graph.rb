=begin
 * Graph class
 *
 * Class to implement and perform Graph operations
=end
class Graph

  # Hash object containing Vertex ID as key and Vertex instance as value
  @vertices
  # Hash object having signal label as key and array of track segment's labels as value
  @terminals
  # Hash object containing Track ID as key and Track instance as value
  @tracks
  # Hash object containing signal ID as key and signal object as value
  @signals
  # Hash object containing label as key and vertex object they are used for, as value
  @labels

  # Constructor method
  def initialize
    # Initializing the attributes according to their class
    @vertices = {}
    @terminals = {}
    @tracks = {}
    @signals = {}
    @labels = {}
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. attribute_name - name of the attribute
  #      (vertices/terminals/tracks/signals/labels)
  # Returns: Value of the attribute passed as parameter
  #
  # Method to get the attribute value
  def get_attribute attribute_name
    case attribute_name
      when :vertices
        return @vertices
      when :terminals
        return @terminals
      when :tracks
        return @tracks
      when :signals
        return @signals
      when :labels
        return @labels
    end
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. vertex_1 - String value having the ID of a vertex
  #   2. vertex_2 - String value having the ID of a vertex
  # Returns: NA
  #
  # Method to add two vertices as objects and
  # add an edge between them
  def add_edge vertex_1, vertex_2
    # Get the objects for the given vertex IDs
    vertex_obj_1 = fetch_object vertex_1
    vertex_obj_2 = fetch_object vertex_2

    # Add edge between the two vertices by adding vertices as adjacents
    # As this is an undirected graph,
    # both the vertices must be added as adjacents to each other
    edge = Edge.new
    edge.set_up_vertex = vertex_obj_1
    edge.set_down_vertex = vertex_obj_2

    vertex_obj_1.add_adjacent edge, vertex_obj_2
    vertex_obj_2.add_adjacent edge, vertex_obj_1
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. signal_info - String value denoting the signal specification between two
  #                     track segments
  # Returns: NA
  #
  # Method to add signal information between two track segments
  # Input format: <vertex_1> (<signal_ID> <direction> <type>) <vertex_2>
  # Explanation: The signal details that are given between two vertices
  def add_signal_info signal_info
    # Splitting the different details such as vertices and signal info
    vertex = signal_info.split('(')[0].split(' ')[0]
    signal_info = signal_info.split('(')[1].chomp
    signal_info = signal_info.split(')')[0].chomp

    # Fetching the object for vertices
    vertex_obj = fetch_object vertex

    # Validating whether they are already specified in the layout graph
    if vertex_obj.get_adjacents.empty?
      raise "Node not found"
    end

    # Creating signal object and assigning the required attributes
    signal = TrainSignal.new
    signal.add_info signal_info
    # Add the Signal instance to signals attribute
    @signals[signal.get_data] = signal

    # Add the Signal instance to the edge between given vertices
    vertex_obj.add_signal signal
    signal.set_vertex = vertex_obj
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. vertices - Array of vertex IDs in String format
  # Returns: NA
  #
  # Method to add impossible paths in a Railway section layout
  # Input format: [vertex_1, vertex_2, vertex_3]
  # Explanation: vertex_2, the point through which a path cannot be practically
  #               reached from vertex_1 to vertex_3 or vice versa
  def add_point_path vertices
    # Fetching the objects for the vertex IDs
    point_vertex = fetch_object vertices[1]
    vertex_objs = [fetch_object(vertices[0]), fetch_object(vertices[2])]

    # Check if the vertex was added already or not
    # Exception is raised in the negative case
    if !vertex_objs.select{ |vertex_obj| vertex_obj.get_adjacents.empty? }.empty? or
      point_vertex.get_adjacents.empty?

      raise "Node not found"
    end

    point_vertex.set_point = vertices[3]
    vertex_objs.map{ |vertex| vertex.set_point = vertices[3] if vertex.get_data.include?(vertices[3]) }

    # Add the vertex objects to the attribute of vertex at point
    point_vertex.add_to_blacklisted_path vertex_objs
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. label_info - String value denoting the label info of a vertex
  # Returns: NA
  #
  # Method to add labels for a vertex
  def add_label label_info
    label_info = label_info.split(' ')

    # Get the Vertex instance for the ID
    vertex_obj = fetch_object label_info[0]

    # Validate if it is already given in layout graph or not
    if vertex_obj.get_adjacents.empty?
      raise "Node not found"
    end

    # Add labels to the vertex and to the attribute
    labels = label_info[1, label_info.length]

    label_validity = true
    labels.each do |label|
      label_validity &&= (label.match(/\w*\d*(-P)*/).to_s == label)
    end
    raise "Invalid label format" unless label_validity

    labels.map { |label| @labels[label.split('-')[0]] = vertex_obj }
    vertex_obj.set_labels = labels
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. track_info - String containing the track ID followed by
  #                   list of vertices separated by space
  # Returns: NA
  #
  # Method to add the track information about all the vertices given for the track
  # Input format: "track_1 vertex_1 vertex_2 vertex_3"
  # Explanation:  vertex_1, vertex_2 and vertex_3 are the vertices that come under
  #               track_1
  def add_track_info track_info
    # Splitting the String into track ID followed by vertex IDs
    track_info = track_info.split(' ')

    # Creating new Track instance with its ID
    track = Track.new
    track.set_data = track_info[0]

    # Adding the track to the list of tracks attribute
    @tracks[track_info[0]] = track

    # For each vertex, fetch its object, check if it has been added already or not and
    # add it to the attribute Track instance along with attribute of Vertex instance
    track_info[1..track_info.length - 1].each do |track_vertex_id|
      track_vertex_obj = fetch_object track_vertex_id

      if track_vertex_obj.get_adjacents.empty?
        raise "Node not found"
      end

      track_vertex_obj.set_track = track
      track.add_vertex track_vertex_obj
    end
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. terminals_info - String value containing the terminal details
  #                       for paths
  # Returns: NA
  #
  # Method to add terminal info of every path in the graph
  def add_terminals terminals_info
    # Split the signal and track labels
    terminals_info = terminals_info.split(' ')

    # Add them to the terminals attribute
    @terminals[terminals_info[0]] = terminals_info[1..terminals_info.length]
  end

  private

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. vertex_data - String value denoting Vertex ID
    # Returns: Vertex Instance
    #
    # Method to find the Vertex instance with its ID
    # If the instance is already in the attribute Hash,
    # the same instance will be returned, or a new instance
    # will be created and returned.
    def fetch_object vertex_data
      # Get the Vertex instance from attribute Hash
      vertex_obj = @vertices[vertex_data]

      # Create a new Vertex instance if not found and return it
      if vertex_obj.nil?
        vertex_obj = Vertex.new
        vertex_obj.set_data = vertex_data
        @vertices[vertex_data] = vertex_obj
      end

      return vertex_obj
    end
end
