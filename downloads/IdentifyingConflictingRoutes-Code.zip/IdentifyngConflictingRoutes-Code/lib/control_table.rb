=begin
 * ControlTable class
 *
 * Class to store control table fields
=end
class ControlTable

  # Vertex instance denoting source
  @source_vertex
  # Vertex instance denoting destination
  @destination_vertex
  # Signal instance denoting source
  @source_signal
  # Label instance denoting destination
  @destination_label
  # Locks and detects points field as Hash instance
  @locks_and_detects_points
  # Array of Hash denoting path from source to destination
  @controlled_by_tracks_hash
  @controlled_by_tracks_array
  # Boolean value indicating whether the instance is for point or not
  @point_info

  # Constructor method
  def initialize
    # Initializing the attributes according to their class
    @source_vertex = nil
    @destination_vertex = nil
    @source_signal = nil
    @destination_label = nil
    @locks_and_detects_points = nil
    @controlled_by_tracks_hash = nil
    @controlled_by_tracks_array = nil
    @point_info = false
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Source Vertex instance
  #
  # Method to get the source Vertex instance of a ControlTable instance
  def get_source_vertex
    @source_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. source_vertex - Source Vertex instance
  # Returns: Source Vertex instance
  #
  # Method to set the source Vertex instance of a ControlTable instance
  def set_source_vertex= source_vertex
    @source_vertex = source_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Source Signal instance
  #
  # Method to get the source Signal instance
  def get_source_signal
    @source_signal
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. source_signal - Source Signal instance
  # Returns: Source Signal instance
  #
  # Method to set the source Signal instance
  def set_source_signal= source_signal
    @source_signal = source_signal
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Destination Vertex instance
  #
  # Method to get the destination Vertex instance
  def get_destination_vertex
    @destination_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. destination_vertex - Destination Vertex instance
  # Returns: Destination Vertex instance
  #
  # Method to set destination Vertex instance
  def set_destination_vertex= destination_vertex
    @destination_vertex = destination_vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Destination Label instance
  #
  # Method to get the destination label instance
  def get_destination_label
    @destination_label
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. destination_label - Destination Label instance
  # Returns: Destination Label instance
  #
  # Method to set the destination Label instance
  def set_destination_label= destination_label
    @destination_label = destination_label
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Locks and detects points as Hash instance
  #
  # Method to get the Locks and detects points as Hash instance
  def get_locks_and_detects_points
    @locks_and_detects_points
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. locks_and_detects_points - Locks and detects points as Hash instance
  # Returns: Locks and detects points as Hash instance
  #
  # Method to set locks and detects points as Hash instance
  def set_locks_and_detects_points= locks_and_detects_points
    @locks_and_detects_points = locks_and_detects_points
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Path of a route as Hash instance
  #
  # Method to get path of a route as Hash instance
  def get_controlled_by_tracks_hash
    @controlled_by_tracks_hash
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. controlled_by_tracks_hash - Path of a route as Hash instance
  # Returns: Path of a route as Hash instance
  #
  # Method to set the path of a route as Hash instance
  def set_controlled_by_tracks_hash= controlled_by_tracks_hash
    @controlled_by_tracks_hash = controlled_by_tracks_hash
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Path of a route as Array instance
  #
  # Method to get the path of a route as Array instance
  def get_controlled_by_tracks_array
    @controlled_by_tracks_array
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. controlled_by_tracks_array - Path of a route as Array instance
  # Returns: Path of a route as Array instance
  #
  # Method to set the path of a route as Array instance
  def set_controlled_by_tracks_array= controlled_by_tracks_array
    @controlled_by_tracks_array = controlled_by_tracks_array
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Boolean value indicating point or not
  #
  # Method to get the point indicator of a ControlTable instance
  def get_point_info
    @point_info
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. point_info - Boolean value indicating point or not
  # Returns: Boolean value indicating point or not
  #
  # Method to set the point indicator of a ControlTable instance
  def set_point_info= point_info
    @point_info = point_info
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: String denoting the signal and label of ControlTable instance
  #
  # Method to get the signal and label of ControlTable instance
  def to_s
    signal_data = @source_vertex ? @source_signal.get_data : @source_signal
    "#{signal_data}-#{@destination_label}"
  end
end