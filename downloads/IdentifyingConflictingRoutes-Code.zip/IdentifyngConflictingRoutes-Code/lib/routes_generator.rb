=begin
 * RouteGenerator class
 *
 * Class to generate routes according to the control table's entry using DFS
=end
class RouteGenerator

  # Signal direction
  @signal_direction
  # Destination label
  @destination_label
  # Path instance
  @path

  # Constructor method
  def initialize
    # Initializing the attributes according to their classes
    @signal_direction = nil
    @destination_label = nil
    @path = nil
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. signal_direction   - Signal direction
  #   2. destination_label  - Destination label - optional
  #   3. path               - Path instance     - optional
  # Returns: Path instance
  #
  # Method to set the attributes of RouteGenerator instance
  def set_attributes signal_direction, destination_label = nil, path = nil
    @signal_direction = signal_direction
    @destination_label = destination_label
    @path = path
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. file_name - Name of input file
  #   2. graph     - Instance of graph which holds the entire input
  # Returns: Array of Path instances
  #
  # Method to geneate all possible and practical paths in an undirected graph
  # using recursive DFS
  def generate_all_paths file_name, graph
    puts "Generating routes for the given input file '#{file_name}'"
    terminals = graph.get_attribute :terminals
    signals = graph.get_attribute :signals
    tracks = graph.get_attribute :tracks
    paths = []
    # Iterate through every UP side and DOWN side terminals
    # to come up with path between them
    terminals.keys.each do |source_signal|
      terminals[source_signal].each do |destination_label|
        puts "  Computing path for " + source_signal + "-" + destination_label

        signal = signals[source_signal] # Get the signal instance
        @signal_direction = signal.get_direction
        signal_type = signal.get_type
        source_vertex = signal.get_vertex
        @path = Path.new # Creating new instance for Path
        @path.set_source_signal = signal
        @path.set_destination_label = destination_label
        @destination_label = destination_label

        # compute the path between source and destination vertices
        # and add it to the attribute
        computed_path = case signal_type
          when TrainSignal::Type::HOME
            # Find path for HOME signal type
            source_vertex = (get_next_vertices(source_vertex)).first
            @path.set_source_vertex = source_vertex
            compute_and_add_path_home source_vertex, false
          when TrainSignal::Type::STARTER
            # Find path for STARTER signal type
            # Starting vertex must be a point. So iterate till it comes.
            while !source_vertex.is_a_point?
              source_vertex = (get_next_vertices(source_vertex)).first
            end
            @path.set_source_vertex = source_vertex
            compute_and_add_path_starter source_vertex
          when TrainSignal::Type::ADVANCED_STARTER
            # Find path for ADVANCED_STARTER signal type
            source_vertex = (get_next_vertices(source_vertex)).first
            @path.set_source_vertex = source_vertex
            compute_and_add_path_adv_starter source_vertex
          when TrainSignal::Type::SHUNT
            # Find path for SHUNT signal type
            source_vertex = (get_next_vertices(source_vertex)).first
            @path.set_source_vertex = source_vertex
            compute_and_add_path_shunt source_vertex
          when TrainSignal::Type::CALLING_ON_HOME
            # There is no need to compute path for CALLING_ON_HOME signal type
            @path.set_source_vertex = (get_next_vertices(source_vertex)).first
            {}
        end
        # Set the computed path to attribute of Path instance and
        # append it to the array
        @path.set_path = computed_path if computed_path
        paths << @path
        puts "  Computing path for " + source_signal + "-" + destination_label + " done!"
      end
    end
    puts "Generating routes for the given input file '#{file_name}' done"
    return paths
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. signal_vertex - Vertex instance of the signal
  # Returns: The immediate next Vertex instance in the direction of signal
  #
  # Method to get the next Vertex instance in the direction of signal
  def get_next_vertex signal_vertex
    get_next_vertices(signal_vertex).first
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. vertex - Vertex instance
  # Returns: Path as hash computed for calling on home signal type
  #
  # Method to compute path as hash for calling on home signal type
  def get_calling_on_home_path vertex
    compute_path_calling_on_home vertex
  end

  private

    # Scope: Private
    # Type: Instance method(recursive)
    # Parameters:
    #   1. vertex         - Vertex instance
    #   2. crossed_label  - Boolean value denoting whether the track with
    #                       destination label has crossed or not while
    #                       traversing the graph using DFS
    # Returns: Path as hash computed for home signal type
    #
    # Method to compute path as hash for home signal type
    def compute_and_add_path_home vertex, crossed_label
      # Get the next vertices' instances that are connected to vertex in the
      # direction of signal
      next_vertices = get_next_vertices vertex
      path = {}
      if crossed_label && vertex.get_labels.any?
        # If the track segment with destination has crossed and
        # the current vertex has a label associated with it,
        # there is our stopping point!
        @path.set_destination_vertex = vertex
      else
        # Search the current vertex's labels for destionation label
        label = vertex.get_label(@destination_label)
        if label
          # The destination label has been found
          if label.get_platform
            # The destination label is a platform
            # Set the attribute of Path instance and prepare the path hash for
            # this vertex
            @path.set_destination_vertex = next_vertices.first
            path = {vertex.get_data => next_vertices.first.get_data}
          else
            # Set crossed_label to be true and traversal must be continued
            # till next vertex with label is reached!
            crossed_label = true
          end
        end
        unless @path.get_destination_vertex
          # If the traversal has not ended yet
          # Iterate through every next vertex that is adjacent to the vertex
          next_vertices.each do |next_vertex|
            # Preapre the path hash for this vertex and make a recursive call
            # for the next adjacent vertex
            path = {vertex.get_data => next_vertex.get_data}
            path.merge!(compute_and_add_path_home(next_vertex, crossed_label))
            if @path.get_destination_vertex
              # If the traversal has ended, stop the iteration
              break
            end
          end
        end
      end
      return path
    end

    # Scope: Private
    # Type: Instance method(recursive)
    # Parameters:
    #   1. vertex - Vertex instance
    # Returns: Path as hash computed for starter signal type
    #
    # Method to compute path as hash for starter signal type
    def compute_and_add_path_starter vertex
      # Get the next vertices' instances that are connected to vertex in the
      # direction of signal
      next_vertices = get_next_vertices vertex
      path = {}
      if vertex.get_label(@destination_label)
        # If the label is in the current vertex the traversal has ended
        @path.set_destination_vertex = vertex
      else
        # If the traversal has not yet ended
        # iterate through the adjacent vertex
        next_vertices.each do |next_vertex|
          # Prepare the path hash for this vertex and make a recursive call
          # for the adjacent vertex
          path = {vertex.get_data => next_vertex.get_data}
          path.merge!(compute_and_add_path_starter(next_vertex))
          if @path.get_destination_vertex
            # If the traversal has ended, stop the iteration
            break
          end
        end
      end
      return path
    end

    # Scope: Private
    # Type: Instance method(recursive)
    # Parameters:
    #   1. vertex - Vertex instance
    # Returns: Path as hash computed for advanced starter signal type
    #
    # Method to compute path as hash for advanced starter signal type
    def compute_and_add_path_adv_starter vertex
      # Get the next vertices' instances that are connected to vertex in the
      # direction of signal
      next_vertices = get_next_vertices vertex
      path = {}
      # Traverse through next vertex to check
      # if they have the destination label
      next_vertices.each do |next_vertex|
        if next_vertex.get_label(@destination_label)
          # Set the destination vertex, prepare the path hash and
          # end the iteration
          @path.set_destination_vertex = next_vertex
          path = {vertex.get_data => vertex.get_data}
          break
        end
      end
      unless @path.get_destination_vertex
        # If the traversal has not yet ended
        # iterate through next vertices and make recursive call
        next_vertices.each do |next_vertex|
          path = {vertex.get_data => next_vertex.get_data}
          path.merge!(compute_and_add_path_adv_starter(next_vertex))
          if @path.get_destination_vertex
            break
          end
        end
      end
      return path
    end

    # Scope: Private
    # Type: Instance method(recursive)
    # Parameters:
    #   1. vertex - Vertex instance
    # Returns: Path as hash computed for shunt signal type
    #
    # Method to compute path as hash for shunt signal type
    def compute_and_add_path_shunt vertex
      # Get the next vertices' instances that are connected to vertex in the
      # direction of signal
      next_vertices = get_next_vertices vertex
      path = {}
      # Iterate through next vertices and check for destination label
      next_vertices.each do |next_vertex|
        if next_vertex.get_label(@destination_label)
          @path.set_destination_vertex = vertex
          break
        end
      end
      unless @path.get_destination_vertex
        # If the destination is not yet found
        # iterate through next vertices and make the recursive call
        next_vertices.each do |next_vertex|
          path = {vertex.get_data => next_vertex.get_data}
          path.merge!(compute_and_add_path_shunt(next_vertex))
          if @path.get_destination_vertex
            break
          end
        end
      end
      return path
    end

    # Scope: Private
    # Type: Instance method(recursive)
    # Parameters:
    #   1. vertex - Vertex instance
    # Returns: Path as hash computed for calling on home signal type
    #
    # Method to compute path as hash for calling on home signal type
    def compute_path_calling_on_home vertex
      # Get the next vertices' instances that are connected to vertex in the
      # direction of signal
      next_vertices = get_next_vertices vertex
      path = {}
      # Iterate through next vertices to check if
      # destination label has been reached or not
      next_vertices.each do |next_vertex|
        if next_vertex.get_label(@destination_label)
          path = {vertex.get_data => next_vertex.get_data}
          break
        end
      end
      if path.empty?
        # If the traversal has not yet ended
        # iterate through next vertices and make recursive call
        next_vertices.each do |next_vertex|
          path = compute_path_calling_on_home(next_vertex)
          if path.any?
            path_temp = {vertex.get_data => next_vertex.get_data}
            path_temp.merge!(path)
            path = path_temp
            break
          end
        end
      end
      return path
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. vertex - Vertex instance
    # Returns: Next vertices that are adjacent to vertex in the direction of
    #           signal
    #
    # Method to find the next vertices that are adjacent to the vertex
    def get_next_vertices vertex
      next_vertices = []
      # Get the adjacents of vertex and select those that are in same direction
      # as signal's direction
      vertex.get_adjacents.values.select do |edge|
        next_vertex = nil
        if @signal_direction == TrainSignal::Direction::UP
          next_vertices << edge.get_up_vertex
        elsif @signal_direction == TrainSignal::Direction::DOWN
          next_vertices << edge.get_down_vertex
        end
      end
      # Remove the duplicates and the vertex itself
      next_vertices = next_vertices.uniq
      next_vertices -= [vertex]
      return next_vertices
    end
end