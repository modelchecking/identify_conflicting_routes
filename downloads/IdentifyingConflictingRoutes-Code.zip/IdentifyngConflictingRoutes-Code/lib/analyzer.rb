=begin
 * Analyzer class
 *
 * Class to generate the reasoning for every combination of routes
=end
class Analyzer

  # Hash instance to store the reasoning
  @category

  # Constructor method
  def initialize
    # Initializing the attribute according to its class
    @category = {}
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. category_key   - (String)Key denoting the signal type of route 1
  #   2. category_value - (Hash)  Value denoting signal type of route 2,
  #                       direction of both routes, signal label of both
  #                       routes and then the reason
  # Returns: NA
  #
  # Method to add the reason for two routes to be consistent or not uniquely
  def add_category category_key, category_value
    # Check if the category_value is a duplicate or not and return
    return if found_duplicate?(category_key, category_value)
    if @category[category_key].nil?
      # If the signal of route 1 is not present, add the value
      @category[category_key] = category_value
    else
      # If the signal of route 1 is already there
      # check for duplicate till the last level and add
      sub_category_key = category_value.keys.first
      sub_category_value = category_value.values.first
      if @category[category_key][sub_category_key].nil?
        # If the signal of route 2 is not present, add the value
        @category[category_key][sub_category_key] = sub_category_value
      else
        # If the signal of route 2 is already there
        # check for duplicate till the last level and add
        direction_key = sub_category_value.keys.first
        direction_value = sub_category_value.values.first
        if @category[category_key][sub_category_key][direction_key].nil?
          # If the direction of both routes is not present, add the value
          @category[category_key][sub_category_key][direction_key] = direction_value
        else
          # If the direction of both routes is already there
          # add the result key and value
          result_key = direction_value.keys.first
          result_value = direction_value.values.first
          @category[category_key][sub_category_key][direction_key][result_key] = result_value
        end
      end
    end
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: String denoting the analysis of all routes reasoning
  #
  # Method to get the reasoning for all routes as string
  def to_s
    output = ""
    @category.each do |category_key, category_value|
      output += "#{TrainSignal::Type::MAPPING.invert[category_key.to_i]}:\n"
      category_value.each do |sub_category_key, sub_category_value|
        sub_cat_type = TrainSignal::Type::MAPPING.invert[sub_category_key.to_i]
        output += "  #{sub_cat_type}:\n"
        sub_category_value.each do |direction_key, direction_value|
          output += "    #{Direction::MAPPING[direction_key]}:\n"
          direction_value.each do |result_key, result_value|
            result_key = result_key.split('_').join('-')
            output += "      #{result_key} - #{print_result(result_value)}\n"
          end
        end
      end
    end
    output
  end

  # Module for Direction
  # Used to denote the direction between two routes
  module Direction
    UNI = "same"
    OPP = "oppo"
    MAPPING = {UNI => "same direction", OPP => "opposite direction"}
  end

  private

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. result_code - Code for reason
    # Returns: String value for reason as code
    #
    # Method to get meaningful reason for code
    def print_result result_code
      case result_code
        when "X"
          "With same route, so impossible"
        when "NC"
          "No Collision"
        when "C"
          "Collision"
        when "PC"
          "Points Conflict"
      end
    end

    # Scope: Private
    # Type: Instance method
    # Parameters:
    #   1. category_key   - (String)Key denoting the signal type of route 1
    #   2. category_value - (Hash)  Value denoting signal type of route 2,
    #                       direction of both routes, signal label of both
    #                       routes and then the reason
    # Returns: Boolean value indicating whether there is already an entry for
    # the reverse combination of routes
    #
    # Method to find if the input reasoning for two routes is duplicate or not
    def found_duplicate? category_key, category_value
      sub_cat_key = category_value.keys.first
      sub_cat_value = category_value.values.first
      dir_key = sub_cat_value.keys.first
      dir_value = sub_cat_value.values.first
      result_key = dir_value.keys.first
      result_keys = result_key.split('_')
      dup_res_key = "#{result_keys[1]}_#{result_keys[0]}"

      !@category[sub_cat_key].nil? &&
      !@category[sub_cat_key][category_key].nil? &&
      !@category[sub_cat_key][category_key][dir_key].nil? &&
      !@category[sub_cat_key][category_key][dir_key][dup_res_key].nil?
    end
end