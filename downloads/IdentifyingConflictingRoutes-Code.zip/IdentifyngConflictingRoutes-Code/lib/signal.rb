=begin
 * TrainSignal class
 *
 * Class to implement and perform TrainSignal operations
=end
class TrainSignal

  # ID of the signal stored as data
  @data
  # Type of signal
  @type
  # Direction of signal either towards UP or DOWN
  @direction
  # Instance of vertex attached with
  @vertex

  # Constructor method
  def initialize
    # Initializing the attributes according to their class
    @data = nil
    @type = Type::UNDEFINED
    @direction = Direction::UNDEFINED
    @vertex = nil
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: ID of signal
  #
  # Method to get the ID of signal
  def get_data
    return @data
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. data - ID of signal
  # Returns: ID of signal
  #
  # Method to set the ID of signal
  def set_data= data
    @data = data
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Type of signal
  #
  # Method to get the type of signal
  def get_type
    return @type
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. type - Type of signal
  # Returns: Type of signal
  #
  # Method to set type of a signal
  def set_type= type
    @type = type
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Direction of the signal
  #
  # Method to get the direction of signal
  def get_direction
    return @direction
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. direction - Direction of the signal
  # Returns: Direction of the signal
  #
  # Method to set the direction of signal
  def set_direction= direction
    @direction = direction
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. info - String containing the details of signal
  #      "<Signal ID> <Direction of signal> <Type of signal>""
  # Returns: Type of signal
  #
  # Method to add information about a signal to the attributes of Signal
  # instance
  def add_info info
    info = info.split(' ')

    @data = info[0]
    @direction = Direction::MAPPING[info[1].downcase]
    @type = Type::MAPPING[info[2].downcase]
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: Vertex instance to which the signal is attached
  #
  # Method to get the vertex instance of a signal
  def get_vertex
    @vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters:
  #   1. vertex - Vertex instance to which the signal is attached
  # Returns: Vertex instance to which the signal is attached
  #
  # Method to set the vertex instance of a signal
  def set_vertex= vertex
    @vertex = vertex
  end

  # Scope: Public
  # Type: Instance method
  # Parameters: NA
  # Returns: String denoting the attributes of signal instance
  #
  # Method to get the attributes value of signal instance
  def to_s
    "<Signal: #{@data}, #{Type::MAPPING.invert[@type]}, #{Direction::MAPPING.invert[@direction]}>"
  end

  # Module for Type of Signal
  # Used to process for type of signal
  module Type
    UNDEFINED = 0
    CALLING_ON_HOME = 1
    HOME = 2
    ADVANCED_STARTER = 3
    SHUNT = 4
    STARTER = 5

    MAPPING = {
      'undefined' => UNDEFINED,
      'calling_on_home' => CALLING_ON_HOME,
      'home' => HOME,
      'advanced_starter' => ADVANCED_STARTER,
      'shunt' => SHUNT,
      'starter' => STARTER
    }
  end

  # Module for Direction of Signal
  # Used to process for direction of signal
  module Direction
    UNDEFINED = 0
    DOWN = 1
    UP = 2

    MAPPING = {
      'undefined' => UNDEFINED,
      'down' => DOWN,
      'up' => UP
    }
  end

end